---
name: Expo SQLite web compat
description: How to use expo-sqlite without breaking web preview in Metro bundler
---

# expo-sqlite Web Compatibility

## Rule
Never import `expo-sqlite` in a file that gets bundled for web (Metro). The `openDatabaseSync` call requires `SharedArrayBuffer` (not available in Replit proxy), and the `openDatabaseAsync` web implementation requires a `.wasm` file Metro can't resolve.

## Pattern (works)
- `lib/db.native.ts` — expo-sqlite implementation (iOS/Android)
- `lib/db.ts` — AsyncStorage implementation (web fallback)

Metro resolution order:
- Native: `db.native.ts` → `db.ts` → picks native ✓
- Web: `db.web.ts` (if exists) → `db.ts` → picks AsyncStorage ✓

**Why:** Replit's Expo web preview doesn't send `Cross-Origin-Opener-Policy` headers required by SharedArrayBuffer. Also, the `.wasm` file used by expo-sqlite's web implementation isn't resolvable by default Metro config.

**How to apply:** Any time expo-sqlite is used in an Expo app that also serves a web preview, create `.native.ts` and base `.ts` files with the same exported interface.
