---
name: Mizan RevenueCat setup
description: How RevenueCat is wired in the Mizan mobile app
---

# Mizan RevenueCat Setup

## Initialization
`initializeRevenueCat()` is called at module top-level in `app/_layout.tsx` (outside any component), NOT inside useEffect. If `EXPO_PUBLIC_REVENUECAT_*` env vars are not set, it logs a warning and returns gracefully — no crash, no Alert dialog.

## Entitlement
Entitlement identifier: `"pro"`

## Keys needed
- `EXPO_PUBLIC_REVENUECAT_TEST_API_KEY` — for dev/Expo Go
- `EXPO_PUBLIC_REVENUECAT_IOS_API_KEY` — for production iOS
- `EXPO_PUBLIC_REVENUECAT_ANDROID_API_KEY` — for production Android

## Seed Script
`scripts/src/seedRevenueCat.ts` — run after connecting RevenueCat integration. Uses `@replit/revenuecat-sdk` (installed at monorepo root with `pnpm add -w`). Creates project, apps, products (monthly + yearly for test/iOS/Android), entitlement "pro", offering "default", and prints the env vars to set.

## Free vs Pro
- Free: 30-day history limit, first BNPL provider only
- Pro: full history, all BNPL providers, budget alerts, CSV export
