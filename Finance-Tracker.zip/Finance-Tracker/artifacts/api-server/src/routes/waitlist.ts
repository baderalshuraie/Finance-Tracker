import { Router } from "express";
import { db, waitlistSignupsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { JoinWaitlistBody } from "@workspace/api-zod";

const waitlistRouter = Router();

waitlistRouter.post("/waitlist", async (req, res) => {
  const parsed = JoinWaitlistBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(422).json({ error: "Validation failed" });
    return;
  }

  const { email, phone, source } = parsed.data;

  const existing = await db
    .select()
    .from(waitlistSignupsTable)
    .where(eq(waitlistSignupsTable.email, email))
    .limit(1);

  if (existing.length > 0) {
    res.status(409).json({ error: "Email is already on the waitlist" });
    return;
  }

  const [signup] = await db
    .insert(waitlistSignupsTable)
    .values({ email, phone: phone ?? null, source: source ?? null })
    .returning();

  res.status(201).json({
    id: signup.id,
    email: signup.email,
    phone: signup.phone,
    source: signup.source,
    createdAt: signup.createdAt.toISOString(),
  });
});

waitlistRouter.get("/waitlist", async (_req, res) => {
  const signups = await db
    .select()
    .from(waitlistSignupsTable)
    .orderBy(waitlistSignupsTable.createdAt);

  res.json(
    signups.map((s) => ({
      id: s.id,
      email: s.email,
      phone: s.phone,
      source: s.source,
      createdAt: s.createdAt.toISOString(),
    }))
  );
});

export default waitlistRouter;
