import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";
import {
  type BudgetLimit,
  type Transaction,
  clearAllData,
  deleteBudgetLimit,
  deleteTransaction,
  getBudgetLimits,
  getTransactions,
  initDatabase,
  insertTransaction,
  setBudgetLimit,
  setMerchantCategory,
  updateTransactionCategory,
} from "@/lib/db";
import { categorize } from "@/lib/categorizer";
import { CATEGORIES } from "@/constants/categories";

const CAT_LABELS_KEY = "mizan:categoryLabels";
const CAT_ORDER_KEY = "mizan:categoryOrder";

const DEFAULT_ORDER = CATEGORIES.map((c) => c.id);

interface AppContextValue {
  transactions: Transaction[];
  budgetLimits: BudgetLimit[];
  categoryLabels: Record<string, string>;
  categoryOrder: string[];
  isLoading: boolean;
  addTransaction: (t: Omit<Transaction, "id" | "createdAt">) => Promise<void>;
  removeTransaction: (id: string) => Promise<void>;
  recategorize: (id: string, category: string) => Promise<void>;
  saveBudget: (category: string, monthlyLimit: number) => Promise<void>;
  removeBudget: (category: string) => Promise<void>;
  setCategoryLabel: (id: string, label: string) => Promise<void>;
  moveCategoryUp: (id: string) => Promise<void>;
  moveCategoryDown: (id: string) => Promise<void>;
  clearData: () => Promise<void>;
  reload: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [budgetLimits, setBudgetLimits] = useState<BudgetLimit[]>([]);
  const [categoryLabels, setCategoryLabels] = useState<Record<string, string>>({});
  const [categoryOrder, setCategoryOrder] = useState<string[]>(DEFAULT_ORDER);
  const [isLoading, setIsLoading] = useState(true);

  const loadAll = useCallback(async () => {
    setIsLoading(true);
    try {
      const [txs, budgets, labelsRaw, orderRaw] = await Promise.all([
        getTransactions(),
        getBudgetLimits(),
        AsyncStorage.getItem(CAT_LABELS_KEY),
        AsyncStorage.getItem(CAT_ORDER_KEY),
      ]);
      setTransactions(txs);
      setBudgetLimits(budgets);
      if (labelsRaw) setCategoryLabels(JSON.parse(labelsRaw));
      if (orderRaw) {
        const savedOrder: string[] = JSON.parse(orderRaw);
        // Merge with defaults so new categories always appear
        const merged = [
          ...savedOrder.filter((id) => DEFAULT_ORDER.includes(id)),
          ...DEFAULT_ORDER.filter((id) => !savedOrder.includes(id)),
        ];
        setCategoryOrder(merged);
      }
    } catch (e) {
      console.error("[AppContext] load error:", e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    initDatabase()
      .then(loadAll)
      .catch((e) => {
        console.error("[AppContext] DB init error:", e);
        setIsLoading(false);
      });
  }, [loadAll]);

  const addTransaction = useCallback(
    async (t: Omit<Transaction, "id" | "createdAt">) => {
      const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
      let category = t.category;
      if (!category || category === "other") {
        category = await categorize(t.merchant, t.provider);
      }
      const tx: Transaction = { ...t, category, id, createdAt: new Date().toISOString() };
      await insertTransaction(tx);
      setTransactions((prev) => [tx, ...prev]);
    },
    []
  );

  const removeTransaction = useCallback(async (id: string) => {
    await deleteTransaction(id);
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const recategorize = useCallback(async (id: string, category: string) => {
    const tx = transactions.find((t) => t.id === id);
    if (!tx) return;
    await updateTransactionCategory(id, category);
    await setMerchantCategory(tx.merchant, category);
    setTransactions((prev) => prev.map((t) => (t.id === id ? { ...t, category } : t)));
  }, [transactions]);

  const saveBudget = useCallback(async (category: string, monthlyLimit: number) => {
    await setBudgetLimit(category, monthlyLimit);
    setBudgetLimits((prev) => {
      const exists = prev.find((b) => b.category === category);
      if (exists) return prev.map((b) => (b.category === category ? { ...b, monthlyLimit } : b));
      return [...prev, { category, monthlyLimit }];
    });
  }, []);

  const removeBudget = useCallback(async (category: string) => {
    await deleteBudgetLimit(category);
    setBudgetLimits((prev) => prev.filter((b) => b.category !== category));
  }, []);

  const setCategoryLabel = useCallback(async (id: string, label: string) => {
    const updated = { ...categoryLabels, [id]: label };
    setCategoryLabels(updated);
    await AsyncStorage.setItem(CAT_LABELS_KEY, JSON.stringify(updated));
  }, [categoryLabels]);

  const persistOrder = async (order: string[]) => {
    await AsyncStorage.setItem(CAT_ORDER_KEY, JSON.stringify(order));
  };

  const moveCategoryUp = useCallback(async (id: string) => {
    setCategoryOrder((prev) => {
      const idx = prev.indexOf(id);
      if (idx <= 0) return prev;
      const next = [...prev];
      [next[idx - 1], next[idx]] = [next[idx], next[idx - 1]];
      persistOrder(next);
      return next;
    });
  }, []);

  const moveCategoryDown = useCallback(async (id: string) => {
    setCategoryOrder((prev) => {
      const idx = prev.indexOf(id);
      if (idx < 0 || idx >= prev.length - 1) return prev;
      const next = [...prev];
      [next[idx], next[idx + 1]] = [next[idx + 1], next[idx]];
      persistOrder(next);
      return next;
    });
  }, []);

  const clearData = useCallback(async () => {
    await clearAllData();
    await AsyncStorage.multiRemove([CAT_LABELS_KEY, CAT_ORDER_KEY]);
    setTransactions([]);
    setBudgetLimits([]);
    setCategoryLabels({});
    setCategoryOrder(DEFAULT_ORDER);
  }, []);

  return (
    <AppContext.Provider
      value={{
        transactions,
        budgetLimits,
        categoryLabels,
        categoryOrder,
        isLoading,
        addTransaction,
        removeTransaction,
        recategorize,
        saveBudget,
        removeBudget,
        setCategoryLabel,
        moveCategoryUp,
        moveCategoryDown,
        clearData,
        reload: loadAll,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
