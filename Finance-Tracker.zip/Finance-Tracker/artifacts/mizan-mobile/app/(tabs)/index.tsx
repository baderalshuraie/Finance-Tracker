import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useMemo } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { type Transaction } from "@/lib/db";
import { useSubscription } from "@/lib/revenuecat";
import { useColors } from "@/hooks/useColors";
import { useCategoryLabel } from "@/hooks/useCategoryLabel";
import { getCategoryById } from "@/constants/categories";

const BNPL_PROVIDERS = ["Tabby", "Tamara"];

function formatSAR(amount: number): string {
  return `SAR ${amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`;
}

function thisMonthISO(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

function TransactionRow({ tx }: { tx: Transaction }) {
  const colors = useColors();
  const cat = getCategoryById(tx.category);
  const label = useCategoryLabel(tx.category);
  const isDebit = tx.type !== "credit";

  return (
    <View style={[styles.txRow, { borderBottomColor: colors.border }]}>
      <View style={[styles.txIcon, { backgroundColor: cat.color + "22" }]}>
        <Ionicons name="receipt-outline" size={18} color={cat.color} />
      </View>
      <View style={styles.txInfo}>
        <Text style={[styles.txMerchant, { color: colors.foreground }]} numberOfLines={1}>
          {tx.merchant}
        </Text>
        <Text style={[styles.txCat, { color: colors.mutedForeground }]}>
          {label} • {tx.date}
        </Text>
      </View>
      <Text style={[styles.txAmount, { color: isDebit ? colors.foreground : colors.success }]}>
        {isDebit ? "-" : "+"}{formatSAR(tx.amount)}
      </Text>
    </View>
  );
}

interface BNPLCardProps {
  provider: string;
  transactions: Transaction[];
  locked: boolean;
}

function BNPLInstallmentRow({ tx }: { tx: Transaction }) {
  const colors = useColors();
  return (
    <View style={[styles.installmentRow, { borderTopColor: colors.border }]}>
      <View style={styles.installmentInfo}>
        <Text style={[styles.installmentMerchant, { color: colors.foreground }]} numberOfLines={1}>
          {tx.merchant}
          {tx.installmentNumber && tx.totalInstallments
            ? ` (${tx.installmentNumber}/${tx.totalInstallments})`
            : ""}
        </Text>
        {tx.dueDate && (
          <Text style={[styles.installmentDue, { color: colors.mutedForeground }]}>
            Due {tx.dueDate}
          </Text>
        )}
      </View>
      <Text style={[styles.installmentAmount, { color: colors.foreground }]}>
        {formatSAR(tx.amount)}
      </Text>
    </View>
  );
}

function BNPLCard({ provider, transactions, locked }: BNPLCardProps) {
  const colors = useColors();
  const [expanded, setExpanded] = React.useState(false);
  const outstanding = transactions.reduce((s, t) => s + t.amount, 0);
  const sorted = [...transactions].sort((a, b) =>
    (a.dueDate ?? "") > (b.dueDate ?? "") ? 1 : -1
  );
  const next = sorted.find((t) => t.dueDate);

  const isTabby = provider === "Tabby";
  const accent = isTabby ? "#7C3AED" : "#059669";

  function handlePress() {
    if (locked) {
      router.push("/paywall");
    } else {
      setExpanded((e) => !e);
    }
  }

  return (
    <TouchableOpacity
      activeOpacity={0.85}
      onPress={handlePress}
      style={[styles.bnplCard, { backgroundColor: colors.card, borderColor: accent + "44" }]}
    >
      {locked && (
        <View style={styles.lockOverlay}>
          <Ionicons name="lock-closed" size={20} color={colors.primary} />
          <Text style={[styles.lockText, { color: colors.primary }]}>Pro</Text>
        </View>
      )}
      <View style={styles.bnplHeader}>
        <View style={[styles.bnplBadge, { backgroundColor: accent + "22" }]}>
          <Text style={[styles.bnplName, { color: accent }]}>{provider}</Text>
        </View>
        <Text style={[styles.bnplCount, { color: colors.mutedForeground }]}>
          {transactions.length} installment{transactions.length !== 1 ? "s" : ""}
        </Text>
      </View>
      <Text style={[styles.bnplTotal, { color: locked ? colors.mutedForeground : colors.foreground }]}>
        {locked ? "Upgrade to see" : formatSAR(outstanding)}
      </Text>
      {next && !locked && !expanded && (
        <Text style={[styles.bnplDue, { color: colors.mutedForeground }]}>
          Next due: {next.dueDate}
        </Text>
      )}
      {!locked && (
        <View style={[styles.bnplExpandHint, { borderTopColor: colors.border }]}>
          <Ionicons
            name={expanded ? "chevron-up" : "chevron-down"}
            size={14}
            color={colors.mutedForeground}
          />
          <Text style={[styles.bnplExpandText, { color: colors.mutedForeground }]}>
            {expanded ? "Hide" : "Breakdown"}
          </Text>
        </View>
      )}
      {expanded && !locked && sorted.map((tx) => (
        <BNPLInstallmentRow key={tx.id} tx={tx} />
      ))}
    </TouchableOpacity>
  );
}

export default function DashboardScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { transactions, isLoading } = useApp();
  const { isSubscribed } = useSubscription();

  const month = thisMonthISO();

  const thisMonthTxs = useMemo(
    () => transactions.filter((t) => t.date.startsWith(month) && t.type !== "credit"),
    [transactions, month]
  );

  const totalSpent = useMemo(
    () => thisMonthTxs.reduce((s, t) => s + t.amount, 0),
    [thisMonthTxs]
  );

  const bnplByProvider = useMemo(() => {
    const bnpl = transactions.filter((t) => t.type === "installment");
    const map: Record<string, Transaction[]> = {};
    for (const t of bnpl) {
      const p = t.provider ?? "Unknown";
      if (!map[p]) map[p] = [];
      map[p].push(t);
    }
    return map;
  }, [transactions]);

  const visibleProviders = useMemo(() => {
    const all = Object.keys(bnplByProvider);
    if (isSubscribed) return all;
    const first = all[0];
    return first ? [first] : [];
  }, [bnplByProvider, isSubscribed]);

  const recentTxs = useMemo(() => transactions.slice(0, 5), [transactions]);

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  if (isLoading) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: Platform.OS === "web" ? 34 : insets.bottom + 16 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={[styles.header, { paddingTop: topPad + 12 }]}>
          <Text style={[styles.logoText, { color: colors.primary }]}>ميزان</Text>
          <Text style={[styles.monthLabel, { color: colors.mutedForeground }]}>
            {new Date().toLocaleDateString("en-SA", { month: "long", year: "numeric" })}
          </Text>
        </View>

        {/* Balance Card */}
        <View style={[styles.balanceCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.balanceLabel, { color: colors.mutedForeground }]}>
            This month's spending
          </Text>
          <Text style={[styles.balanceAmount, { color: colors.foreground }]}>
            {formatSAR(totalSpent)}
          </Text>
          <Text style={[styles.balanceSub, { color: colors.mutedForeground }]}>
            {thisMonthTxs.length} transaction{thisMonthTxs.length !== 1 ? "s" : ""}
          </Text>
        </View>

        {/* Pro upgrade banner — free users only */}
        {!isSubscribed && (
          <TouchableOpacity
            onPress={() => router.push("/paywall")}
            activeOpacity={0.85}
            style={[styles.upgradeBanner, { backgroundColor: colors.primary + "18", borderColor: colors.primary + "40" }]}
          >
            <Ionicons name="star" size={16} color={colors.primary} />
            <View style={styles.upgradeBannerText}>
              <Text style={[styles.upgradeBannerTitle, { color: colors.primary }]}>
                Unlock Mizan Pro
              </Text>
              <Text style={[styles.upgradeBannerSub, { color: colors.mutedForeground }]}>
                Full history · All BNPL · Budget alerts · CSV export
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={16} color={colors.primary} />
          </TouchableOpacity>
        )}

        {/* BNPL Section */}
        <View style={styles.section}>
          <View style={styles.sectionRow}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              BNPL Overview
            </Text>
            {!isSubscribed && Object.keys(bnplByProvider).length > 1 && (
              <TouchableOpacity onPress={() => router.push("/paywall")}>
                <Text style={[styles.proHint, { color: colors.primary }]}>
                  See all — Pro
                </Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Aggregate outstanding total — scoped to visible providers for free users */}
          {visibleProviders.length > 0 && (
            <View style={[styles.bnplAggregate, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.bnplAggLeft}>
                <Text style={[styles.bnplAggLabel, { color: colors.mutedForeground }]}>
                  {isSubscribed ? "Total BNPL Outstanding" : `${visibleProviders[0]} Outstanding`}
                </Text>
                <Text style={[styles.bnplAggAmount, { color: colors.primary }]}>
                  {formatSAR(
                    visibleProviders
                      .flatMap((p) => bnplByProvider[p] ?? [])
                      .reduce((s, t) => s + t.amount, 0)
                  )}
                </Text>
              </View>
              <View style={styles.bnplAggRight}>
                <Text style={[styles.bnplAggCount, { color: colors.mutedForeground }]}>
                  {visibleProviders.flatMap((p) => bnplByProvider[p] ?? []).length} installments
                </Text>
                <Text style={[styles.bnplAggProviders, { color: colors.mutedForeground }]}>
                  {visibleProviders.join(" · ")}
                </Text>
              </View>
            </View>
          )}

          {visibleProviders.length === 0 ? (
            <View style={[styles.emptyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <MaterialCommunityIcons name="credit-card-outline" size={32} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                No BNPL installments yet
              </Text>
              <Text style={[styles.emptySubText, { color: colors.mutedForeground }]}>
                Paste a Tabby or Tamara SMS to add one
              </Text>
            </View>
          ) : (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.bnplScroll}>
              {visibleProviders.map((p) => (
                <BNPLCard
                  key={p}
                  provider={p}
                  transactions={bnplByProvider[p]}
                  locked={false}
                />
              ))}
              {!isSubscribed &&
                Object.keys(bnplByProvider)
                  .filter((p) => !visibleProviders.includes(p))
                  .map((p) => (
                    <BNPLCard key={p} provider={p} transactions={bnplByProvider[p]} locked />
                  ))}
            </ScrollView>
          )}
        </View>

        {/* Recent Transactions */}
        <View style={styles.section}>
          <View style={styles.sectionRow}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Recent
            </Text>
            <TouchableOpacity onPress={() => router.push("/(tabs)/transactions")}>
              <Text style={[styles.seeAll, { color: colors.primary }]}>See all</Text>
            </TouchableOpacity>
          </View>

          {recentTxs.length === 0 ? (
            <View style={[styles.emptyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Ionicons name="receipt-outline" size={32} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                No transactions yet
              </Text>
              <Text style={[styles.emptySubText, { color: colors.mutedForeground }]}>
                Tap + to add your first transaction
              </Text>
            </View>
          ) : (
            <View style={[styles.txList, { backgroundColor: colors.card, borderColor: colors.border }]}>
              {recentTxs.map((tx) => (
                <TransactionRow key={tx.id} tx={tx} />
              ))}
            </View>
          )}
        </View>
      </ScrollView>

      {/* FAB */}
      <TouchableOpacity
        style={[styles.fab, { backgroundColor: colors.primary, bottom: (Platform.OS === "web" ? 34 : insets.bottom) + 100 }]}
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          router.push("/add");
        }}
      >
        <Ionicons name="add" size={28} color={colors.primaryForeground} />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 8,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  logoText: { fontSize: 28, fontWeight: "700" },
  monthLabel: { fontSize: 14 },
  balanceCard: {
    marginHorizontal: 16,
    marginVertical: 12,
    borderRadius: 16,
    borderWidth: 1,
    padding: 20,
  },
  balanceLabel: { fontSize: 13, marginBottom: 4 },
  balanceAmount: { fontSize: 34, fontWeight: "700", letterSpacing: -0.5 },
  balanceSub: { fontSize: 13, marginTop: 4 },
  upgradeBanner: {
    marginHorizontal: 16,
    marginBottom: 4,
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  upgradeBannerText: { flex: 1 },
  upgradeBannerTitle: { fontSize: 13, fontWeight: "700" },
  upgradeBannerSub: { fontSize: 11, marginTop: 1 },
  section: { marginTop: 8, paddingHorizontal: 16 },
  sectionRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  sectionTitle: { fontSize: 17, fontWeight: "600" },
  seeAll: { fontSize: 14 },
  proHint: { fontSize: 13, fontWeight: "500" },
  bnplAggregate: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  bnplAggLeft: { flex: 1 },
  bnplAggLabel: { fontSize: 12, marginBottom: 4 },
  bnplAggAmount: { fontSize: 22, fontWeight: "700" },
  bnplAggRight: { alignItems: "flex-end" },
  bnplAggCount: { fontSize: 13, fontWeight: "500" },
  bnplAggProviders: { fontSize: 11, marginTop: 2 },
  installmentRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingTop: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
    gap: 8,
  },
  installmentInfo: { flex: 1 },
  installmentMerchant: { fontSize: 13, fontWeight: "500" },
  installmentDue: { fontSize: 11, marginTop: 1 },
  installmentAmount: { fontSize: 13, fontWeight: "600" },
  bnplExpandHint: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: 6,
    paddingTop: 6,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  bnplExpandText: { fontSize: 11 },
  bnplScroll: { marginHorizontal: -16, paddingHorizontal: 16 },
  bnplCard: {
    width: 190,
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    marginRight: 12,
    position: "relative",
    overflow: "hidden",
  },
  bnplHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  bnplBadge: { borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 },
  bnplName: { fontSize: 12, fontWeight: "700" },
  bnplCount: { fontSize: 11 },
  bnplTotal: { fontSize: 20, fontWeight: "700", marginBottom: 4 },
  bnplDue: { fontSize: 12 },
  lockOverlay: {
    position: "absolute",
    top: 12,
    right: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  lockText: { fontSize: 11, fontWeight: "700" },
  txList: { borderRadius: 14, borderWidth: 1, overflow: "hidden" },
  txRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 10,
  },
  txIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  txInfo: { flex: 1 },
  txMerchant: { fontSize: 14, fontWeight: "600" },
  txCat: { fontSize: 12, marginTop: 1 },
  txAmount: { fontSize: 14, fontWeight: "600" },
  emptyCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 24,
    alignItems: "center",
    gap: 8,
  },
  emptyText: { fontSize: 15, fontWeight: "600" },
  emptySubText: { fontSize: 13, textAlign: "center" },
  fab: {
    position: "absolute",
    right: 20,
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
});
