import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  ActionSheetIOS,
  Alert,
  FlatList,
  Platform,
  Pressable,
  Share,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CATEGORIES, getCategoryById } from "@/constants/categories";
import { useApp } from "@/context/AppContext";
import { type Transaction } from "@/lib/db";
import { useSubscription } from "@/lib/revenuecat";
import { useColors } from "@/hooks/useColors";

function formatSAR(amount: number): string {
  return `SAR ${amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`;
}

function thirtyDaysAgoISO(): string {
  const d = new Date();
  d.setDate(d.getDate() - 30);
  return d.toISOString().split("T")[0];
}

function TransactionRow({
  tx,
  onDelete,
  onRecategorize,
}: {
  tx: Transaction;
  onDelete: () => void;
  onRecategorize: () => void;
}) {
  const colors = useColors();
  const cat = getCategoryById(tx.category);
  const isDebit = tx.type !== "credit";

  return (
    <Pressable
      onLongPress={() => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        if (Platform.OS === "ios") {
          ActionSheetIOS.showActionSheetWithOptions(
            {
              options: ["Cancel", "Change Category", "Delete"],
              destructiveButtonIndex: 2,
              cancelButtonIndex: 0,
            },
            (idx) => {
              if (idx === 1) onRecategorize();
              if (idx === 2) onDelete();
            }
          );
        } else {
          Alert.alert(tx.merchant, undefined, [
            { text: "Change Category", onPress: onRecategorize },
            { text: "Delete", style: "destructive", onPress: onDelete },
            { text: "Cancel", style: "cancel" },
          ]);
        }
      }}
      style={({ pressed }) => [
        styles.txRow,
        { borderBottomColor: colors.border, opacity: pressed ? 0.7 : 1 },
      ]}
    >
      <View style={[styles.txIcon, { backgroundColor: cat.color + "22" }]}>
        <Ionicons name="receipt-outline" size={18} color={cat.color} />
      </View>
      <View style={styles.txInfo}>
        <Text style={[styles.txMerchant, { color: colors.foreground }]} numberOfLines={1}>
          {tx.merchant}
        </Text>
        <Text style={[styles.txMeta, { color: colors.mutedForeground }]}>
          {cat.label}
          {tx.provider && tx.provider !== "Unknown" ? ` • ${tx.provider}` : ""}
          {tx.installmentNumber && tx.totalInstallments
            ? ` (${tx.installmentNumber}/${tx.totalInstallments})`
            : ""}
        </Text>
        <Text style={[styles.txDate, { color: colors.mutedForeground }]}>{tx.date}</Text>
      </View>
      <View style={styles.txRight}>
        <Text style={[styles.txAmount, { color: isDebit ? colors.foreground : colors.success }]}>
          {isDebit ? "-" : "+"}{formatSAR(tx.amount)}
        </Text>
        {tx.dueDate && (
          <Text style={[styles.txDue, { color: colors.warning }]}>Due {tx.dueDate}</Text>
        )}
      </View>
    </Pressable>
  );
}

export default function TransactionsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { transactions, removeTransaction, recategorize } = useApp();
  const { isSubscribed } = useSubscription();

  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [filterMonth, setFilterMonth] = useState<string>(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  });

  const cutoff = !isSubscribed ? thirtyDaysAgoISO() : null;

  const filtered = useMemo(() => {
    let list = transactions;
    if (cutoff) list = list.filter((t) => t.date >= cutoff);
    if (filterMonth) list = list.filter((t) => t.date.startsWith(filterMonth));
    if (selectedCategory) list = list.filter((t) => t.category === selectedCategory);
    return list;
  }, [transactions, cutoff, filterMonth, selectedCategory]);

  function prevMonth() {
    const [y, m] = filterMonth.split("-").map(Number);
    const d = new Date(y, m - 2, 1);
    setFilterMonth(
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
    );
  }

  function nextMonth() {
    const [y, m] = filterMonth.split("-").map(Number);
    const d = new Date(y, m, 1);
    setFilterMonth(
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
    );
  }

  async function exportCSV() {
    if (!isSubscribed) {
      router.push("/paywall");
      return;
    }
    const header = "Date,Merchant,Amount,Category,Type,Provider,Notes";
    const rows = filtered.map(
      (t) =>
        `${t.date},"${t.merchant}",${t.amount},${t.category},${t.type},${t.provider ?? ""},${t.notes ?? ""}`
    );
    const csv = [header, ...rows].join("\n");
    try {
      await Share.share({ message: csv, title: "Mizan Transactions" });
    } catch (e) {
      console.warn("Export error:", e);
    }
  }

  function handleRecategorize(tx: Transaction) {
    if (Platform.OS === "ios") {
      ActionSheetIOS.showActionSheetWithOptions(
        {
          options: ["Cancel", ...CATEGORIES.map((c) => c.label)],
          cancelButtonIndex: 0,
        },
        (idx) => {
          if (idx === 0) return;
          recategorize(tx.id, CATEGORIES[idx - 1].id);
        }
      );
    } else {
      Alert.alert(
        "Change Category",
        undefined,
        CATEGORIES.map((c) => ({
          text: c.label,
          onPress: () => recategorize(tx.id, c.id),
        }))
      );
    }
  }

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const totalFiltered = filtered.filter((t) => t.type !== "credit").reduce((s, t) => s + t.amount, 0);

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          { paddingTop: topPad + 12, backgroundColor: colors.background, borderBottomColor: colors.border },
        ]}
      >
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Transactions</Text>
        <TouchableOpacity onPress={exportCSV} style={styles.exportBtn}>
          <Ionicons name="share-outline" size={20} color={isSubscribed ? colors.primary : colors.mutedForeground} />
          {!isSubscribed && (
            <Ionicons name="lock-closed" size={11} color={colors.primary} style={styles.lockIcon} />
          )}
        </TouchableOpacity>
      </View>

      {/* Month Navigator */}
      <View style={[styles.monthBar, { backgroundColor: colors.card, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={prevMonth} style={styles.monthBtn}>
          <Ionicons name="chevron-back" size={20} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.monthText, { color: colors.foreground }]}>
          {new Date(filterMonth + "-15").toLocaleDateString("en-SA", { month: "long", year: "numeric" })}
        </Text>
        <TouchableOpacity onPress={nextMonth} style={styles.monthBtn}>
          <Ionicons name="chevron-forward" size={20} color={colors.foreground} />
        </TouchableOpacity>
      </View>

      {/* Category Filter */}
      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={[null, ...CATEGORIES]}
        keyExtractor={(item) => item?.id ?? "all"}
        style={[styles.catFilter, { borderBottomColor: colors.border }]}
        contentContainerStyle={{ paddingHorizontal: 16, gap: 8, paddingVertical: 10 }}
        renderItem={({ item }) => {
          const active = selectedCategory === (item?.id ?? null);
          return (
            <TouchableOpacity
              onPress={() => setSelectedCategory(item?.id ?? null)}
              style={[
                styles.catChip,
                {
                  backgroundColor: active ? colors.primary : colors.card,
                  borderColor: active ? colors.primary : colors.border,
                },
              ]}
            >
              <Text style={[styles.catChipText, { color: active ? colors.primaryForeground : colors.mutedForeground }]}>
                {item?.label ?? "All"}
              </Text>
            </TouchableOpacity>
          );
        }}
      />

      {!isSubscribed && (
        <TouchableOpacity
          onPress={() => router.push("/paywall")}
          style={[styles.proBar, { backgroundColor: colors.primary + "22", borderBottomColor: colors.border }]}
        >
          <Ionicons name="lock-closed" size={14} color={colors.primary} />
          <Text style={[styles.proBarText, { color: colors.primary }]}>
            Pro: Full history beyond 30 days — Upgrade
          </Text>
        </TouchableOpacity>
      )}

      {/* Summary */}
      <View style={[styles.summary, { borderBottomColor: colors.border }]}>
        <Text style={[styles.summaryText, { color: colors.mutedForeground }]}>
          {filtered.length} transactions • {formatSAR(totalFiltered)}
        </Text>
      </View>

      {/* List */}
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        scrollEnabled={!!filtered.length}
        contentContainerStyle={{
          paddingBottom: Platform.OS === "web" ? 34 : insets.bottom + 80,
        }}
        renderItem={({ item }) => (
          <TransactionRow
            tx={item}
            onDelete={() => removeTransaction(item.id)}
            onRecategorize={() => handleRecategorize(item)}
          />
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="receipt-outline" size={40} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              No transactions
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  headerTitle: { fontSize: 24, fontWeight: "700" },
  exportBtn: { padding: 4, position: "relative" },
  lockIcon: { position: "absolute", bottom: 0, right: 0 },
  monthBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 8,
    paddingVertical: 8,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  monthBtn: { padding: 8 },
  monthText: { fontSize: 15, fontWeight: "600" },
  catFilter: { borderBottomWidth: StyleSheet.hairlineWidth, flexGrow: 0 },
  catChip: {
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 5,
  },
  catChipText: { fontSize: 13, fontWeight: "500" },
  proBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 8,
    gap: 6,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  proBarText: { fontSize: 12, fontWeight: "500" },
  summary: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  summaryText: { fontSize: 12 },
  txRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 10,
  },
  txIcon: {
    width: 38,
    height: 38,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
  txInfo: { flex: 1 },
  txMerchant: { fontSize: 14, fontWeight: "600" },
  txMeta: { fontSize: 12, marginTop: 1 },
  txDate: { fontSize: 11, marginTop: 1 },
  txRight: { alignItems: "flex-end" },
  txAmount: { fontSize: 14, fontWeight: "600" },
  txDue: { fontSize: 11, marginTop: 2 },
  empty: { alignItems: "center", paddingTop: 80, gap: 12 },
  emptyText: { fontSize: 16 },
  success: {},
  warning: {},
});
