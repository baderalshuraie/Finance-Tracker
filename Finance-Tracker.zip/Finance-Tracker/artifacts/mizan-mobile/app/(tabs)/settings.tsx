import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CATEGORIES, getCategoryById } from "@/constants/categories";
import { useApp } from "@/context/AppContext";
import { useSubscription } from "@/lib/revenuecat";
import { useColors } from "@/hooks/useColors";

function SettingRow({
  icon,
  label,
  sub,
  onPress,
  value,
  destructive,
  right,
}: {
  icon: string;
  label: string;
  sub?: string;
  onPress?: () => void;
  value?: string;
  destructive?: boolean;
  right?: React.ReactNode;
}) {
  const colors = useColors();
  const color = destructive ? colors.destructive : colors.foreground;

  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      style={[styles.row, { borderBottomColor: colors.border }]}
    >
      <View style={[styles.rowIcon, { backgroundColor: (destructive ? colors.destructive : colors.primary) + "22" }]}>
        <Ionicons name={icon as any} size={18} color={destructive ? colors.destructive : colors.primary} />
      </View>
      <View style={styles.rowContent}>
        <Text style={[styles.rowLabel, { color }]}>{label}</Text>
        {sub && <Text style={[styles.rowSub, { color: colors.mutedForeground }]}>{sub}</Text>}
      </View>
      {right ?? (value ? (
        <Text style={[styles.rowValue, { color: colors.mutedForeground }]}>{value}</Text>
      ) : (
        onPress && <Ionicons name="chevron-forward" size={18} color={colors.mutedForeground} />
      ))}
    </TouchableOpacity>
  );
}

function SectionHeader({ title }: { title: string }) {
  const colors = useColors();
  return (
    <Text style={[styles.sectionHeader, { color: colors.mutedForeground }]}>{title}</Text>
  );
}

function RenameCategoryModal({
  categoryId,
  currentLabel,
  onSave,
  onClose,
}: {
  categoryId: string;
  currentLabel: string;
  onSave: (label: string) => void;
  onClose: () => void;
}) {
  const colors = useColors();
  const [value, setValue] = useState(currentLabel);
  const original = getCategoryById(categoryId).label;

  return (
    <View style={styles.modalBackdrop}>
      <View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.modalTitle, { color: colors.foreground }]}>Rename Category</Text>
        <Text style={[styles.modalSub, { color: colors.mutedForeground }]}>
          Default: {original}
        </Text>
        <TextInput
          style={[styles.modalInput, { backgroundColor: colors.input, color: colors.foreground, borderColor: colors.border }]}
          value={value}
          onChangeText={setValue}
          placeholder={original}
          placeholderTextColor={colors.mutedForeground}
          autoFocus
          maxLength={30}
        />
        <View style={styles.modalButtons}>
          <TouchableOpacity
            onPress={() => { setValue(original); onSave(original); }}
            style={[styles.modalBtn, { borderColor: colors.border }]}
          >
            <Text style={[styles.modalBtnText, { color: colors.mutedForeground }]}>Reset</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              const trimmed = value.trim();
              if (trimmed.length > 0) onSave(trimmed);
            }}
            style={[styles.modalBtn, styles.modalBtnPrimary, { backgroundColor: colors.primary }]}
          >
            <Text style={[styles.modalBtnText, { color: colors.primaryForeground }]}>Save</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity onPress={onClose} style={styles.modalClose}>
          <Ionicons name="close" size={20} color={colors.mutedForeground} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { clearData, categoryLabels, categoryOrder, setCategoryLabel, moveCategoryUp, moveCategoryDown } = useApp();
  const { isSubscribed, isLoading, restore, isRestoring, hasKey } = useSubscription();
  const [renamingCategoryId, setRenamingCategoryId] = useState<string | null>(null);

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  async function handleRestore() {
    if (!hasKey) {
      Alert.alert("Not Available", "RevenueCat is not configured yet.");
      return;
    }
    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      await restore();
      Alert.alert("Restored", "Your purchases have been restored.");
    } catch (e: any) {
      Alert.alert("Error", e?.message ?? "Failed to restore purchases.");
    }
  }

  function handleClearData() {
    Alert.alert(
      "Clear All Data",
      "This will permanently delete all your transactions, budgets, and settings. This cannot be undone.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Clear Everything",
          style: "destructive",
          onPress: async () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
            await clearData();
          },
        },
      ]
    );
  }

  const renamingCategory = renamingCategoryId
    ? CATEGORIES.find((c) => c.id === renamingCategoryId)
    : null;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 12, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Settings</Text>
      </View>

      <ScrollView
        contentContainerStyle={{
          paddingBottom: Platform.OS === "web" ? 34 : insets.bottom + 80,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Pro Status */}
        {!isSubscribed && (
          <TouchableOpacity
            onPress={() => router.push("/paywall")}
            style={[styles.proCard, { backgroundColor: colors.primary + "18", borderColor: colors.primary + "44" }]}
          >
            <View style={styles.proCardLeft}>
              <Ionicons name="star" size={20} color={colors.primary} />
              <View>
                <Text style={[styles.proCardTitle, { color: colors.primary }]}>Upgrade to Mizan Pro</Text>
                <Text style={[styles.proCardSub, { color: colors.mutedForeground }]}>
                  Full history, budget alerts, CSV export
                </Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={18} color={colors.primary} />
          </TouchableOpacity>
        )}

        {isSubscribed && (
          <View style={[styles.proCard, { backgroundColor: colors.success + "18", borderColor: colors.success + "44" }]}>
            <View style={styles.proCardLeft}>
              <Ionicons name="checkmark-circle" size={20} color={colors.success} />
              <View>
                <Text style={[styles.proCardTitle, { color: colors.success }]}>Mizan Pro Active</Text>
                <Text style={[styles.proCardSub, { color: colors.mutedForeground }]}>
                  All features unlocked
                </Text>
              </View>
            </View>
          </View>
        )}

        <SectionHeader title="SUBSCRIPTION" />
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {!isSubscribed && (
            <SettingRow
              icon="star-outline"
              label="Upgrade to Pro"
              onPress={() => router.push("/paywall")}
            />
          )}
          <SettingRow
            icon="refresh-outline"
            label="Restore Purchases"
            sub={isRestoring ? "Restoring..." : undefined}
            onPress={handleRestore}
          />
        </View>

        <SectionHeader title="CATEGORIES" />
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {categoryOrder.map((catId, idx) => {
            const cat = CATEGORIES.find((c) => c.id === catId);
            if (!cat) return null;
            const customLabel = categoryLabels[cat.id];
            const displayLabel = customLabel ?? cat.label;
            return (
              <View key={cat.id} style={[styles.catRow, { borderBottomColor: colors.border }]}>
                <View style={[styles.catDot, { backgroundColor: cat.color }]} />
                <TouchableOpacity
                  onPress={() => setRenamingCategoryId(cat.id)}
                  activeOpacity={0.7}
                  style={styles.catRowContent}
                >
                  <Text style={[styles.rowLabel, { color: colors.foreground }]}>{displayLabel}</Text>
                  {customLabel && customLabel !== cat.label && (
                    <Text style={[styles.rowSub, { color: colors.mutedForeground }]}>
                      Default: {cat.label}
                    </Text>
                  )}
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => moveCategoryUp(cat.id)}
                  disabled={idx === 0}
                  style={[styles.reorderBtn, { opacity: idx === 0 ? 0.25 : 1 }]}
                >
                  <Ionicons name="chevron-up" size={16} color={colors.mutedForeground} />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => moveCategoryDown(cat.id)}
                  disabled={idx === categoryOrder.length - 1}
                  style={[styles.reorderBtn, { opacity: idx === categoryOrder.length - 1 ? 0.25 : 1 }]}
                >
                  <Ionicons name="chevron-down" size={16} color={colors.mutedForeground} />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setRenamingCategoryId(cat.id)}
                  style={styles.reorderBtn}
                >
                  <Ionicons name="pencil-outline" size={16} color={colors.mutedForeground} />
                </TouchableOpacity>
              </View>
            );
          })}
        </View>

        <SectionHeader title="DATA" />
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <SettingRow
            icon="information-circle-outline"
            label="Data Storage"
            value="On-device only"
          />
          <SettingRow
            icon="shield-checkmark-outline"
            label="Privacy"
            sub="All data stays on your device — never uploaded"
          />
          <SettingRow
            icon="trash-outline"
            label="Clear All Data"
            destructive
            onPress={handleClearData}
          />
        </View>

        <SectionHeader title="ABOUT" />
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <SettingRow
            icon="information-outline"
            label="Version"
            value="1.0.0"
          />
          <SettingRow
            icon="logo-github"
            label="App"
            value="Mizan ميزان"
          />
          <SettingRow
            icon="earth-outline"
            label="Region"
            value="Saudi Arabia / GCC"
          />
        </View>

      </ScrollView>

      {renamingCategory && (
        <RenameCategoryModal
          categoryId={renamingCategory.id}
          currentLabel={categoryLabels[renamingCategory.id] ?? renamingCategory.label}
          onSave={async (label) => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            await setCategoryLabel(renamingCategory.id, label);
            setRenamingCategoryId(null);
          }}
          onClose={() => setRenamingCategoryId(null)}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  headerTitle: { fontSize: 24, fontWeight: "700" },
  proCard: {
    margin: 16,
    marginBottom: 8,
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  proCardLeft: { flexDirection: "row", alignItems: "center", gap: 12, flex: 1 },
  proCardTitle: { fontSize: 15, fontWeight: "700" },
  proCardSub: { fontSize: 12, marginTop: 2 },
  sectionHeader: {
    fontSize: 12,
    fontWeight: "600",
    letterSpacing: 0.8,
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 8,
  },
  section: {
    marginHorizontal: 16,
    borderRadius: 14,
    borderWidth: 1,
    overflow: "hidden",
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 12,
  },
  catRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 8,
  },
  catRowContent: { flex: 1 },
  reorderBtn: { padding: 4 },
  catDot: { width: 12, height: 12, borderRadius: 6, flexShrink: 0 },
  rowIcon: {
    width: 34,
    height: 34,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  rowContent: { flex: 1 },
  rowLabel: { fontSize: 15 },
  rowSub: { fontSize: 12, marginTop: 1 },
  rowValue: { fontSize: 14 },
  modalBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.7)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  modalCard: {
    width: "100%",
    borderRadius: 20,
    borderWidth: 1,
    padding: 24,
    gap: 12,
    position: "relative",
  },
  modalTitle: { fontSize: 18, fontWeight: "700" },
  modalSub: { fontSize: 14 },
  modalInput: {
    borderRadius: 10,
    borderWidth: 1,
    padding: 14,
    fontSize: 16,
    fontWeight: "500",
  },
  modalButtons: { flexDirection: "row", gap: 12 },
  modalBtn: {
    flex: 1,
    borderRadius: 10,
    borderWidth: 1,
    padding: 14,
    alignItems: "center",
  },
  modalBtnPrimary: { borderWidth: 0 },
  modalBtnText: { fontSize: 15, fontWeight: "600" },
  modalClose: {
    position: "absolute",
    top: 16,
    right: 16,
    padding: 4,
  },
});
