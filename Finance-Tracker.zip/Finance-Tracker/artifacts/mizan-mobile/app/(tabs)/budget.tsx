import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CATEGORIES, type Category, getCategoryById } from "@/constants/categories";
import { useApp } from "@/context/AppContext";
import { useSubscription } from "@/lib/revenuecat";
import { useColors } from "@/hooks/useColors";
import { useCategoryLabel } from "@/hooks/useCategoryLabel";

function formatSAR(amount: number): string {
  return `SAR ${amount.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`;
}

function thisMonthISO(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

function BudgetBar({ spent, limit, alertsEnabled }: { spent: number; limit: number; alertsEnabled: boolean }) {
  const colors = useColors();
  const pct = Math.min(spent / limit, 1);
  const progress = useSharedValue(0);

  React.useEffect(() => {
    progress.value = withTiming(pct, { duration: 600 });
  }, [pct]);

  const barStyle = useAnimatedStyle(() => ({
    width: `${progress.value * 100}%`,
    backgroundColor: alertsEnabled
      ? progress.value >= 1
        ? colors.destructive
        : progress.value >= 0.8
        ? colors.warning
        : colors.primary
      : colors.primary,
  }));

  return (
    <View style={[styles.barBg, { backgroundColor: colors.muted }]}>
      <Animated.View style={[styles.barFill, barStyle]} />
    </View>
  );
}

function BudgetCard({
  category,
  spent,
  limit,
  alertsEnabled,
  onEdit,
  onDelete,
}: {
  category: Category;
  spent: number;
  limit: number;
  alertsEnabled: boolean;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const colors = useColors();
  const label = useCategoryLabel(category.id);
  const pct = limit > 0 ? spent / limit : 0;
  const isOver = alertsEnabled && pct >= 1;
  const isWarn = alertsEnabled && pct >= 0.8 && pct < 1;
  const statusColor = isOver ? colors.destructive : isWarn ? colors.warning : colors.mutedForeground;
  const borderColor = isOver ? colors.destructive + "55" : isWarn ? colors.warning + "44" : colors.border;

  return (
    <Pressable
      onLongPress={() => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        Alert.alert(label, undefined, [
          { text: "Edit Budget", onPress: onEdit },
          { text: "Remove Budget", style: "destructive", onPress: onDelete },
          { text: "Cancel", style: "cancel" },
        ]);
      }}
      style={[styles.budgetCard, { backgroundColor: colors.card, borderColor }]}
    >
      <View style={styles.budgetHeader}>
        <View style={[styles.catDot, { backgroundColor: category.color }]} />
        <Text style={[styles.catLabel, { color: colors.foreground }]}>{label}</Text>
        <Text style={[styles.pctText, { color: statusColor }]}>
          {Math.round(pct * 100)}%
          {isOver ? " OVER" : isWarn ? " WARN" : ""}
        </Text>
      </View>
      <BudgetBar spent={spent} limit={limit} alertsEnabled={alertsEnabled} />
      <View style={styles.budgetFooter}>
        <Text style={[styles.spentText, { color: colors.foreground }]}>
          {formatSAR(spent)}
        </Text>
        <Text style={[styles.limitText, { color: colors.mutedForeground }]}>
          of {formatSAR(limit)}
        </Text>
      </View>
      {isOver && (
        <Text style={[styles.overText, { color: colors.destructive }]}>
          Over by {formatSAR(spent - limit)}
        </Text>
      )}
    </Pressable>
  );
}

function SetBudgetModal({
  category,
  current,
  onSave,
  onClose,
}: {
  category: Category;
  current?: number;
  onSave: (amount: number) => void;
  onClose: () => void;
}) {
  const colors = useColors();
  const [value, setValue] = useState(current ? String(current) : "");

  return (
    <View style={[styles.modalBackdrop]}>
      <View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.modalTitle, { color: colors.foreground }]}>
          Budget for {category.label}
        </Text>
        <Text style={[styles.modalSub, { color: colors.mutedForeground }]}>
          Monthly limit in SAR
        </Text>
        <TextInput
          style={[styles.modalInput, { backgroundColor: colors.input, color: colors.foreground, borderColor: colors.border }]}
          value={value}
          onChangeText={setValue}
          keyboardType="numeric"
          placeholder="0"
          placeholderTextColor={colors.mutedForeground}
          autoFocus
        />
        <View style={styles.modalButtons}>
          <TouchableOpacity
            onPress={onClose}
            style={[styles.modalBtn, { borderColor: colors.border }]}
          >
            <Text style={[styles.modalBtnText, { color: colors.mutedForeground }]}>Cancel</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              const n = parseFloat(value);
              if (!isNaN(n) && n > 0) onSave(n);
            }}
            style={[styles.modalBtn, styles.modalBtnPrimary, { backgroundColor: colors.primary }]}
          >
            <Text style={[styles.modalBtnText, { color: colors.primaryForeground }]}>Save</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

export default function BudgetScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { transactions, budgetLimits, saveBudget, removeBudget } = useApp();
  const { isSubscribed } = useSubscription();

  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [showAddPicker, setShowAddPicker] = useState(false);

  const month = thisMonthISO();

  const spendingByCategory = useMemo(() => {
    const map: Record<string, number> = {};
    for (const t of transactions) {
      if (t.date.startsWith(month) && t.type !== "credit") {
        map[t.category] = (map[t.category] ?? 0) + t.amount;
      }
    }
    return map;
  }, [transactions, month]);

  const budgetMap = useMemo(() => {
    const map: Record<string, number> = {};
    for (const b of budgetLimits) {
      map[b.category] = b.monthlyLimit;
    }
    return map;
  }, [budgetLimits]);

  const unconfiguredCategories = CATEGORIES.filter((c) => !budgetMap[c.id]);

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View
        style={[styles.header, { paddingTop: topPad + 12, borderBottomColor: colors.border }]}
      >
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Budget</Text>
        <Text style={[styles.headerSub, { color: colors.mutedForeground }]}>
          {new Date().toLocaleDateString("en-SA", { month: "long", year: "numeric" })}
        </Text>
      </View>

      {!isSubscribed && (
        <TouchableOpacity
          onPress={() => router.push("/paywall")}
          style={[styles.proBar, { backgroundColor: colors.primary + "22", borderBottomColor: colors.border }]}
        >
          <Ionicons name="lock-closed" size={14} color={colors.primary} />
          <Text style={[styles.proBarText, { color: colors.primary }]}>
            Pro: Budget alerts at 80% & 100% — Upgrade
          </Text>
        </TouchableOpacity>
      )}

      <ScrollView
        contentContainerStyle={{
          padding: 16,
          gap: 12,
          paddingBottom: Platform.OS === "web" ? 34 : insets.bottom + 80,
        }}
        showsVerticalScrollIndicator={false}
      >
        {budgetLimits.length === 0 && (
          <View style={[styles.emptyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons name="pie-chart-outline" size={36} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              No budgets set yet
            </Text>
            <Text style={[styles.emptySub, { color: colors.mutedForeground }]}>
              Tap + to set a monthly budget per category
            </Text>
          </View>
        )}

        {budgetLimits.map((b) => {
          const cat = getCategoryById(b.category);
          return (
            <BudgetCard
              key={b.category}
              category={cat}
              spent={spendingByCategory[b.category] ?? 0}
              limit={b.monthlyLimit}
              alertsEnabled={isSubscribed}
              onEdit={() => setEditingCategory(cat)}
              onDelete={() => removeBudget(b.category)}
            />
          );
        })}

        {/* Spending without budget */}
        {Object.entries(spendingByCategory)
          .filter(([cat]) => !budgetMap[cat])
          .sort(([, a], [, b]) => b - a)
          .map(([catId, spent]) => {
            const cat = getCategoryById(catId);
            return (
              <TouchableOpacity
                key={catId}
                onPress={() => setEditingCategory(cat)}
                style={[styles.unbudgetedCard, { backgroundColor: colors.card, borderColor: colors.border }]}
              >
                <View style={styles.budgetHeader}>
                  <View style={[styles.catDot, { backgroundColor: cat.color }]} />
                  <Text style={[styles.catLabel, { color: colors.foreground }]}>{cat.label}</Text>
                  <Text style={[styles.spentUnbudgeted, { color: colors.mutedForeground }]}>
                    {formatSAR(spent)}
                  </Text>
                </View>
                <Text style={[styles.setBudgetHint, { color: colors.primary }]}>
                  Tap to set budget
                </Text>
              </TouchableOpacity>
            );
          })}

        {unconfiguredCategories.length > 0 && (
          <TouchableOpacity
            onPress={() => setShowAddPicker(true)}
            style={[styles.addBudgetBtn, { borderColor: colors.border }]}
          >
            <Ionicons name="add-circle-outline" size={20} color={colors.primary} />
            <Text style={[styles.addBudgetText, { color: colors.primary }]}>
              Add Budget Category
            </Text>
          </TouchableOpacity>
        )}
      </ScrollView>

      {/* Category picker for add */}
      {showAddPicker && (
        <View style={[styles.modalBackdrop]}>
          <View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>
              Choose Category
            </Text>
            <ScrollView style={{ maxHeight: 300 }}>
              {unconfiguredCategories.map((c) => (
                <TouchableOpacity
                  key={c.id}
                  onPress={() => {
                    setShowAddPicker(false);
                    setEditingCategory(c);
                  }}
                  style={[styles.pickerRow, { borderBottomColor: colors.border }]}
                >
                  <View style={[styles.catDot, { backgroundColor: c.color }]} />
                  <Text style={[styles.catLabel, { color: colors.foreground }]}>{c.label}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <TouchableOpacity onPress={() => setShowAddPicker(false)} style={[styles.modalBtn, { borderColor: colors.border, marginTop: 8 }]}>
              <Text style={[styles.modalBtnText, { color: colors.mutedForeground }]}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {editingCategory && (
        <SetBudgetModal
          category={editingCategory}
          current={budgetMap[editingCategory.id]}
          onSave={async (amount) => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            await saveBudget(editingCategory.id, amount);
            setEditingCategory(null);
          }}
          onClose={() => setEditingCategory(null)}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    flexDirection: "row",
    alignItems: "baseline",
    justifyContent: "space-between",
  },
  headerTitle: { fontSize: 24, fontWeight: "700" },
  headerSub: { fontSize: 14 },
  proBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 8,
    gap: 6,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  proBarText: { fontSize: 12, fontWeight: "500" },
  budgetCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    gap: 10,
  },
  budgetHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  catDot: { width: 10, height: 10, borderRadius: 5 },
  catLabel: { flex: 1, fontSize: 15, fontWeight: "600" },
  pctText: { fontSize: 13, fontWeight: "600" },
  barBg: { height: 6, borderRadius: 3, overflow: "hidden" },
  barFill: { height: 6, borderRadius: 3 },
  budgetFooter: { flexDirection: "row", alignItems: "center", gap: 6 },
  spentText: { fontSize: 16, fontWeight: "700" },
  limitText: { fontSize: 13 },
  overText: { fontSize: 12, fontWeight: "600" },
  unbudgetedCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    gap: 6,
  },
  spentUnbudgeted: { fontSize: 15 },
  setBudgetHint: { fontSize: 12 },
  addBudgetBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 14,
    borderWidth: 1,
    borderStyle: "dashed",
    padding: 16,
    gap: 8,
  },
  addBudgetText: { fontSize: 15, fontWeight: "500" },
  emptyCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 32,
    alignItems: "center",
    gap: 8,
  },
  emptyText: { fontSize: 16, fontWeight: "600" },
  emptySub: { fontSize: 13, textAlign: "center" },
  modalBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.7)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  modalCard: {
    width: "100%",
    borderRadius: 20,
    borderWidth: 1,
    padding: 24,
    gap: 12,
  },
  modalTitle: { fontSize: 18, fontWeight: "700" },
  modalSub: { fontSize: 14 },
  modalInput: {
    borderRadius: 10,
    borderWidth: 1,
    padding: 14,
    fontSize: 20,
    fontWeight: "600",
  },
  modalButtons: { flexDirection: "row", gap: 12 },
  modalBtn: {
    flex: 1,
    borderRadius: 10,
    borderWidth: 1,
    padding: 14,
    alignItems: "center",
  },
  modalBtnPrimary: { borderWidth: 0 },
  modalBtnText: { fontSize: 16, fontWeight: "600" },
  pickerRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 12,
  },
});
