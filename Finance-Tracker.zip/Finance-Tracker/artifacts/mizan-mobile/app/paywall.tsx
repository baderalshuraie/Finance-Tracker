import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useSubscription } from "@/lib/revenuecat";
import { useColors } from "@/hooks/useColors";

const PRO_FEATURES = [
  { icon: "layers-outline", label: "Multi-BNPL Dashboard", sub: "See all Tabby & Tamara installments" },
  { icon: "bar-chart-outline", label: "Budget Alerts", sub: "Notifications at 80% and 100% of budget" },
  { icon: "time-outline", label: "Full History", sub: "Unlimited transaction history" },
  { icon: "share-outline", label: "CSV Export", sub: "Export transactions to spreadsheets" },
];

export default function PaywallScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { offerings, purchase, restore, isPurchasing, isRestoring, isSubscribed, hasKey } = useSubscription();

  const [selectedPkg, setSelectedPkg] = useState<number>(0);
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  if (isSubscribed) {
    return (
      <View style={[styles.root, { backgroundColor: colors.background }]}>
        <View style={[styles.header, { paddingTop: topPad + 8 }]}>
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="close" size={24} color={colors.foreground} />
          </TouchableOpacity>
        </View>
        <View style={styles.center}>
          <Ionicons name="checkmark-circle" size={64} color={colors.success} />
          <Text style={[styles.title, { color: colors.foreground }]}>You're on Pro!</Text>
          <Text style={[styles.sub, { color: colors.mutedForeground }]}>
            All features are unlocked.
          </Text>
          <TouchableOpacity
            onPress={() => router.back()}
            style={[styles.mainBtn, { backgroundColor: colors.primary }]}
          >
            <Text style={[styles.mainBtnText, { color: colors.primaryForeground }]}>Back</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const packages = offerings?.current?.availablePackages ?? [];

  async function handlePurchase() {
    if (!hasKey) {
      Alert.alert(
        "Not Available",
        "Payments are being set up. Please check back soon."
      );
      return;
    }
    if (packages.length === 0) {
      Alert.alert("Not Available", "No packages found. Please try again later.");
      return;
    }
    const pkg = packages[selectedPkg] ?? packages[0];
    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      await purchase(pkg);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert("Welcome to Pro!", "All features are now unlocked.", [
        { text: "OK", onPress: () => router.back() },
      ]);
    } catch (e: any) {
      if (!e?.userCancelled) {
        Alert.alert("Purchase Failed", e?.message ?? "Something went wrong.");
      }
    }
  }

  async function handleRestore() {
    if (!hasKey) {
      Alert.alert("Not Available", "Payments are being set up.");
      return;
    }
    try {
      await restore();
      Alert.alert("Restored", "Your purchases have been restored.");
    } catch (e: any) {
      Alert.alert("Restore Failed", e?.message ?? "Nothing to restore.");
    }
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: bottomPad + 120 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={[styles.header, { paddingTop: topPad + 8 }]}>
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="close" size={24} color={colors.foreground} />
          </TouchableOpacity>
        </View>

        {/* Hero */}
        <View style={styles.hero}>
          <View style={[styles.iconCircle, { backgroundColor: colors.primary + "22", borderColor: colors.primary + "55" }]}>
            <Text style={[styles.iconText, { color: colors.primary }]}>ميزان</Text>
          </View>
          <Text style={[styles.title, { color: colors.foreground }]}>Mizan Pro</Text>
          <Text style={[styles.sub, { color: colors.mutedForeground }]}>
            Complete financial clarity for Saudi users
          </Text>
        </View>

        {/* Features */}
        <View style={styles.features}>
          {PRO_FEATURES.map((f) => (
            <View key={f.icon} style={[styles.featureRow, { borderBottomColor: colors.border }]}>
              <View style={[styles.featureIcon, { backgroundColor: colors.primary + "22" }]}>
                <Ionicons name={f.icon as any} size={20} color={colors.primary} />
              </View>
              <View style={styles.featureText}>
                <Text style={[styles.featureLabel, { color: colors.foreground }]}>{f.label}</Text>
                <Text style={[styles.featureSub, { color: colors.mutedForeground }]}>{f.sub}</Text>
              </View>
              <Ionicons name="checkmark-circle" size={20} color={colors.success} />
            </View>
          ))}
        </View>

        {/* Package Selection */}
        <View style={styles.packages}>
          {packages.length === 0 ? (
            <View style={[styles.pkgCard, styles.pkgSelected, { borderColor: colors.primary, backgroundColor: colors.card }]}>
              <View>
                <Text style={[styles.pkgLabel, { color: colors.foreground }]}>Mizan Pro Monthly</Text>
                <Text style={[styles.pkgPrice, { color: colors.primary }]}>
                  {hasKey ? "Loading..." : "Coming Soon"}
                </Text>
              </View>
            </View>
          ) : (
            packages.map((pkg, i) => {
              const isSelected = i === selectedPkg;
              return (
                <TouchableOpacity
                  key={pkg.identifier}
                  onPress={() => setSelectedPkg(i)}
                  style={[
                    styles.pkgCard,
                    { backgroundColor: colors.card, borderColor: isSelected ? colors.primary : colors.border },
                    isSelected && styles.pkgSelected,
                  ]}
                >
                  {pkg.packageType === "ANNUAL" && (
                    <View style={[styles.badgeBestValue, { backgroundColor: colors.primary }]}>
                      <Text style={[styles.badgeText, { color: colors.primaryForeground }]}>Best Value</Text>
                    </View>
                  )}
                  <View>
                    <Text style={[styles.pkgLabel, { color: colors.foreground }]}>
                      {pkg.product.title}
                    </Text>
                    <Text style={[styles.pkgPrice, { color: isSelected ? colors.primary : colors.foreground }]}>
                      {pkg.product.priceString}
                      <Text style={[styles.pkgPeriod, { color: colors.mutedForeground }]}>
                        {" "}/{pkg.packageType === "ANNUAL" ? "year" : "month"}
                      </Text>
                    </Text>
                  </View>
                  {isSelected && (
                    <Ionicons name="checkmark-circle" size={22} color={colors.primary} />
                  )}
                </TouchableOpacity>
              );
            })
          )}
        </View>
      </ScrollView>

      {/* CTA */}
      <View
        style={[
          styles.cta,
          {
            backgroundColor: colors.background,
            borderTopColor: colors.border,
            paddingBottom: bottomPad + 16,
          },
        ]}
      >
        <TouchableOpacity
          onPress={handlePurchase}
          disabled={isPurchasing}
          style={[styles.mainBtn, { backgroundColor: colors.primary }]}
        >
          {isPurchasing ? (
            <ActivityIndicator color={colors.primaryForeground} />
          ) : (
            <Text style={[styles.mainBtnText, { color: colors.primaryForeground }]}>
              {packages.length > 0 ? `Subscribe — ${packages[selectedPkg]?.product.priceString ?? ""}` : "Get Mizan Pro"}
            </Text>
          )}
        </TouchableOpacity>
        <TouchableOpacity onPress={handleRestore} disabled={isRestoring} style={styles.restoreBtn}>
          <Text style={[styles.restoreText, { color: colors.mutedForeground }]}>
            {isRestoring ? "Restoring..." : "Restore Purchases"}
          </Text>
        </TouchableOpacity>
        <Text style={[styles.legal, { color: colors.mutedForeground }]}>
          Subscription auto-renews. Cancel anytime in App Store settings.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  center: { flex: 1, alignItems: "center", justifyContent: "center", padding: 24, gap: 16 },
  hero: { alignItems: "center", paddingHorizontal: 24, paddingTop: 8, paddingBottom: 24, gap: 12 },
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  iconText: { fontSize: 22, fontWeight: "700" },
  title: { fontSize: 28, fontWeight: "700" },
  sub: { fontSize: 15, textAlign: "center", lineHeight: 22 },
  features: { paddingHorizontal: 20 },
  featureRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 12,
  },
  featureIcon: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  featureText: { flex: 1 },
  featureLabel: { fontSize: 15, fontWeight: "600" },
  featureSub: { fontSize: 12, marginTop: 2 },
  packages: { padding: 20, gap: 10 },
  pkgCard: {
    borderRadius: 14,
    borderWidth: 1.5,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    position: "relative",
    overflow: "hidden",
  },
  pkgSelected: {},
  pkgLabel: { fontSize: 15, fontWeight: "600" },
  pkgPrice: { fontSize: 20, fontWeight: "700", marginTop: 4 },
  pkgPeriod: { fontSize: 14, fontWeight: "400" },
  badgeBestValue: {
    position: "absolute",
    top: 0,
    right: 0,
    borderBottomLeftRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 3,
  },
  badgeText: { fontSize: 11, fontWeight: "700" },
  cta: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 20,
    paddingTop: 16,
    borderTopWidth: StyleSheet.hairlineWidth,
    gap: 10,
  },
  mainBtn: {
    borderRadius: 14,
    padding: 16,
    alignItems: "center",
  },
  mainBtnText: { fontSize: 17, fontWeight: "700" },
  restoreBtn: { alignItems: "center", padding: 4 },
  restoreText: { fontSize: 14 },
  legal: { fontSize: 11, textAlign: "center", lineHeight: 16 },
});
