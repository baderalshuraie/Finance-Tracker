import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  ActionSheetIOS,
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CATEGORIES } from "@/constants/categories";
import { useApp } from "@/context/AppContext";
import { type Transaction } from "@/lib/db";
import { parseSMS } from "@/lib/smsParser";
import { categorizeSync } from "@/lib/categorizer";
import { useColors } from "@/hooks/useColors";

type TxType = "debit" | "credit" | "installment";

export default function AddScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { addTransaction } = useApp();

  const [smsText, setSmsText] = useState("");
  const [showSMS, setShowSMS] = useState(false);
  const [amount, setAmount] = useState("");
  const [merchant, setMerchant] = useState("");
  const [category, setCategory] = useState("other");
  const [date, setDate] = useState(() => new Date().toISOString().split("T")[0]);
  const [type, setType] = useState<TxType>("debit");
  const [provider, setProvider] = useState("");
  const [notes, setNotes] = useState("");
  const [installmentNum, setInstallmentNum] = useState("");
  const [installmentTotal, setInstallmentTotal] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  function parseSMSInput() {
    const parsed = parseSMS(smsText);
    if (!parsed) {
      Alert.alert("Could not parse", "No recognizable amount found in this SMS. Please fill the form manually.");
      return;
    }
    setAmount(String(parsed.amount));
    setMerchant(parsed.merchant);
    setDate(parsed.date);
    setType(parsed.type);
    setProvider(parsed.provider !== "Unknown" ? parsed.provider : "");
    if (parsed.installmentNumber) setInstallmentNum(String(parsed.installmentNumber));
    if (parsed.totalInstallments) setInstallmentTotal(String(parsed.totalInstallments));
    if (parsed.dueDate) setDueDate(parsed.dueDate);

    const cat = categorizeSync(parsed.merchant, parsed.provider);
    setCategory(cat);

    setShowSMS(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  }

  async function handleSave() {
    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      Alert.alert("Invalid Amount", "Please enter a valid amount.");
      return;
    }
    if (!merchant.trim()) {
      Alert.alert("Missing Merchant", "Please enter a merchant name.");
      return;
    }
    setIsSaving(true);
    try {
      const tx: Omit<Transaction, "id" | "createdAt"> = {
        amount: amountNum,
        merchant: merchant.trim(),
        category,
        date,
        type,
        provider: provider.trim() || undefined,
        notes: notes.trim() || undefined,
        installmentNumber: installmentNum ? parseInt(installmentNum) : undefined,
        totalInstallments: installmentTotal ? parseInt(installmentTotal) : undefined,
        dueDate: dueDate || undefined,
      };
      await addTransaction(tx);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch (e: any) {
      Alert.alert("Error", e?.message ?? "Failed to save transaction.");
    } finally {
      setIsSaving(false);
    }
  }

  function pickCategory() {
    if (Platform.OS === "ios") {
      ActionSheetIOS.showActionSheetWithOptions(
        {
          options: ["Cancel", ...CATEGORIES.map((c) => c.label)],
          cancelButtonIndex: 0,
        },
        (idx) => {
          if (idx === 0) return;
          setCategory(CATEGORIES[idx - 1].id);
        }
      );
    } else {
      Alert.alert(
        "Category",
        undefined,
        CATEGORIES.map((c) => ({ text: c.label, onPress: () => setCategory(c.id) }))
      );
    }
  }

  function pickType() {
    if (Platform.OS === "ios") {
      ActionSheetIOS.showActionSheetWithOptions(
        { options: ["Cancel", "Debit", "Credit", "BNPL Installment"], cancelButtonIndex: 0 },
        (idx) => {
          if (idx === 0) return;
          setType((["debit", "credit", "installment"] as TxType[])[idx - 1]);
        }
      );
    } else {
      Alert.alert("Transaction Type", undefined, [
        { text: "Debit", onPress: () => setType("debit") },
        { text: "Credit", onPress: () => setType("credit") },
        { text: "BNPL Installment", onPress: () => setType("installment") },
        { text: "Cancel", style: "cancel" },
      ]);
    }
  }

  const catLabel = CATEGORIES.find((c) => c.id === category)?.label ?? "Other";
  const typeLabel = { debit: "Debit", credit: "Credit", installment: "BNPL Installment" }[type];
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 8, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeBtn}>
          <Ionicons name="close" size={24} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Add Transaction</Text>
        <TouchableOpacity
          onPress={handleSave}
          disabled={isSaving}
          style={[styles.saveBtn, { backgroundColor: colors.primary }]}
        >
          <Text style={[styles.saveBtnText, { color: colors.primaryForeground }]}>
            {isSaving ? "..." : "Save"}
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={{ padding: 16, gap: 12, paddingBottom: Platform.OS === "web" ? 34 : insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* SMS Parser Toggle */}
        <TouchableOpacity
          onPress={() => setShowSMS(!showSMS)}
          style={[styles.smsToggle, { backgroundColor: colors.card, borderColor: colors.border }]}
        >
          <Ionicons name="chatbubble-outline" size={18} color={colors.primary} />
          <Text style={[styles.smsToggleText, { color: colors.primary }]}>
            {showSMS ? "Hide SMS Parser" : "Paste Bank SMS"}
          </Text>
          <Ionicons name={showSMS ? "chevron-up" : "chevron-down"} size={16} color={colors.primary} />
        </TouchableOpacity>

        {showSMS && (
          <View style={[styles.smsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>
              Paste SMS from AlRajhi, SAB, STC Pay, Tabby, or Tamara
            </Text>
            <TextInput
              style={[styles.smsInput, { backgroundColor: colors.input, color: colors.foreground, borderColor: colors.border }]}
              value={smsText}
              onChangeText={setSmsText}
              placeholder="Paste SMS here..."
              placeholderTextColor={colors.mutedForeground}
              multiline
              numberOfLines={4}
            />
            <TouchableOpacity
              onPress={parseSMSInput}
              style={[styles.parseBtn, { backgroundColor: colors.primary }]}
            >
              <Text style={[styles.parseBtnText, { color: colors.primaryForeground }]}>
                Parse SMS
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Amount */}
        <View style={[styles.inputCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Amount (SAR)</Text>
          <TextInput
            style={[styles.amountInput, { color: colors.foreground }]}
            value={amount}
            onChangeText={setAmount}
            keyboardType="numeric"
            placeholder="0.00"
            placeholderTextColor={colors.mutedForeground}
          />
        </View>

        {/* Merchant */}
        <View style={[styles.inputCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Merchant</Text>
          <TextInput
            style={[styles.textInput, { color: colors.foreground, borderColor: colors.border }]}
            value={merchant}
            onChangeText={setMerchant}
            placeholder="e.g. Noon, HungerStation"
            placeholderTextColor={colors.mutedForeground}
          />
        </View>

        {/* Type + Category row */}
        <View style={styles.rowInputs}>
          <TouchableOpacity
            onPress={pickType}
            style={[styles.halfCard, { backgroundColor: colors.card, borderColor: colors.border }]}
          >
            <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Type</Text>
            <Text style={[styles.pickerValue, { color: colors.foreground }]}>{typeLabel}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={pickCategory}
            style={[styles.halfCard, { backgroundColor: colors.card, borderColor: colors.border }]}
          >
            <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Category</Text>
            <Text style={[styles.pickerValue, { color: colors.foreground }]}>{catLabel}</Text>
          </TouchableOpacity>
        </View>

        {/* Date */}
        <View style={[styles.inputCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Date (YYYY-MM-DD)</Text>
          <TextInput
            style={[styles.textInput, { color: colors.foreground, borderColor: colors.border }]}
            value={date}
            onChangeText={setDate}
            placeholder="2025-01-15"
            placeholderTextColor={colors.mutedForeground}
          />
        </View>

        {/* Provider */}
        <View style={[styles.inputCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Provider (optional)</Text>
          <TextInput
            style={[styles.textInput, { color: colors.foreground, borderColor: colors.border }]}
            value={provider}
            onChangeText={setProvider}
            placeholder="e.g. Tabby, AlRajhi"
            placeholderTextColor={colors.mutedForeground}
          />
        </View>

        {/* BNPL fields */}
        {type === "installment" && (
          <>
            <View style={styles.rowInputs}>
              <View style={[styles.halfCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Installment #</Text>
                <TextInput
                  style={[styles.textInput, { color: colors.foreground, borderColor: colors.border }]}
                  value={installmentNum}
                  onChangeText={setInstallmentNum}
                  keyboardType="numeric"
                  placeholder="1"
                  placeholderTextColor={colors.mutedForeground}
                />
              </View>
              <View style={[styles.halfCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Total Installments</Text>
                <TextInput
                  style={[styles.textInput, { color: colors.foreground, borderColor: colors.border }]}
                  value={installmentTotal}
                  onChangeText={setInstallmentTotal}
                  keyboardType="numeric"
                  placeholder="4"
                  placeholderTextColor={colors.mutedForeground}
                />
              </View>
            </View>
            <View style={[styles.inputCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Due Date (YYYY-MM-DD)</Text>
              <TextInput
                style={[styles.textInput, { color: colors.foreground, borderColor: colors.border }]}
                value={dueDate}
                onChangeText={setDueDate}
                placeholder="2025-02-01"
                placeholderTextColor={colors.mutedForeground}
              />
            </View>
          </>
        )}

        {/* Notes */}
        <View style={[styles.inputCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Notes (optional)</Text>
          <TextInput
            style={[styles.textInput, { color: colors.foreground, borderColor: colors.border }]}
            value={notes}
            onChangeText={setNotes}
            placeholder="Any notes..."
            placeholderTextColor={colors.mutedForeground}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 8,
  },
  closeBtn: { padding: 4 },
  headerTitle: { flex: 1, fontSize: 18, fontWeight: "600", textAlign: "center" },
  saveBtn: { borderRadius: 8, paddingHorizontal: 16, paddingVertical: 8 },
  saveBtnText: { fontSize: 15, fontWeight: "600" },
  smsToggle: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    gap: 8,
  },
  smsToggleText: { flex: 1, fontSize: 15, fontWeight: "500" },
  smsCard: { borderRadius: 12, borderWidth: 1, padding: 14, gap: 10 },
  smsInput: {
    borderRadius: 8,
    borderWidth: 1,
    padding: 10,
    fontSize: 13,
    minHeight: 80,
    textAlignVertical: "top",
  },
  parseBtn: { borderRadius: 8, padding: 12, alignItems: "center" },
  parseBtnText: { fontSize: 15, fontWeight: "600" },
  inputCard: { borderRadius: 12, borderWidth: 1, padding: 14, gap: 6 },
  inputLabel: { fontSize: 12, fontWeight: "500" },
  amountInput: { fontSize: 32, fontWeight: "700" },
  textInput: { borderRadius: 8, borderWidth: 1, padding: 10, fontSize: 15 },
  rowInputs: { flexDirection: "row", gap: 10 },
  halfCard: { flex: 1, borderRadius: 12, borderWidth: 1, padding: 14, gap: 6 },
  pickerValue: { fontSize: 15, fontWeight: "500" },
});
