export interface Category {
  id: string;
  label: string;
  labelAr: string;
  color: string;
}

export const CATEGORIES: Category[] = [
  { id: "food",             label: "Food & Dining",    labelAr: "طعام",    color: "#E07832" },
  { id: "groceries",        label: "Groceries",        labelAr: "بقالة",   color: "#3aa85a" },
  { id: "transport",        label: "Transport",        labelAr: "مواصلات", color: "#3B82F6" },
  { id: "shopping",         label: "Shopping",         labelAr: "تسوق",    color: "#8B5CF6" },
  { id: "bnpl_installment", label: "BNPL Installment", labelAr: "تقسيط",   color: "#D1A847" },
  { id: "healthcare",       label: "Healthcare",       labelAr: "صحة",     color: "#EF4444" },
  { id: "transfers",        label: "Transfers",        labelAr: "تحويلات", color: "#6B7280" },
  { id: "other",            label: "Other",            labelAr: "أخرى",    color: "#9CA3AF" },
];

export function getCategoryById(id: string): Category {
  return CATEGORIES.find((c) => c.id === id) ?? CATEGORIES[CATEGORIES.length - 1];
}

export const CATEGORY_IDS = CATEGORIES.map((c) => c.id);
