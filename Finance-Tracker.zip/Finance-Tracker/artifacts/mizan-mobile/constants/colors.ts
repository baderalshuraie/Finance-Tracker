const colors = {
  light: {
    text: "#fafafa",
    tint: "#D1A847",

    background: "#0d100f",
    foreground: "#fafafa",

    card: "#131715",
    cardForeground: "#fafafa",

    primary: "#D1A847",
    primaryForeground: "#0d100f",

    secondary: "#1a1e1c",
    secondaryForeground: "#fafafa",

    muted: "#1a1e1c",
    mutedForeground: "#9da5a3",

    accent: "#1e2421",
    accentForeground: "#fafafa",

    destructive: "#a52222",
    destructiveForeground: "#fafafa",

    border: "#232927",
    input: "#1e2421",

    success: "#3aa85a",
    warning: "#D1A847",
  },

  dark: {
    text: "#fafafa",
    tint: "#D1A847",

    background: "#0d100f",
    foreground: "#fafafa",

    card: "#131715",
    cardForeground: "#fafafa",

    primary: "#D1A847",
    primaryForeground: "#0d100f",

    secondary: "#1a1e1c",
    secondaryForeground: "#fafafa",

    muted: "#1a1e1c",
    mutedForeground: "#9da5a3",

    accent: "#1e2421",
    accentForeground: "#fafafa",

    destructive: "#a52222",
    destructiveForeground: "#fafafa",

    border: "#232927",
    input: "#1e2421",

    success: "#3aa85a",
    warning: "#D1A847",
  },

  radius: 8,
};

export default colors;
