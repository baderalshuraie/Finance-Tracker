export interface ParsedSMS {
  amount: number;
  merchant: string;
  date: string;
  type: "debit" | "credit" | "installment";
  provider: string;
  installmentNumber?: number;
  totalInstallments?: number;
  dueDate?: string;
}

export function parseSMS(text: string): ParsedSMS | null {
  if (!text || !text.trim()) return null;
  const t = text.trim();
  return (
    parseTabby(t) ||
    parseTamara(t) ||
    parseAlRajhi(t) ||
    parseSAB(t) ||
    parseSTCPay(t) ||
    parseGeneric(t)
  );
}

function extractAmount(text: string): number | null {
  const sarMatch = text.match(/SAR\s*([\d,]+\.?\d*)/i);
  if (sarMatch) return parseFloat(sarMatch[1].replace(/,/g, ""));

  const arabicMatch = text.match(/([\d,]+\.?\d*)\s*ريال/);
  if (arabicMatch) return parseFloat(arabicMatch[1].replace(/,/g, ""));

  const decimalMatch = text.match(/\b(\d{1,6}\.\d{2})\b/);
  if (decimalMatch) return parseFloat(decimalMatch[1]);

  return null;
}

function todayISO(): string {
  return new Date().toISOString().split("T")[0];
}

function parseDateStr(raw: string): string {
  if (!raw) return todayISO();
  const dmy = raw.match(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/);
  if (dmy) {
    const [, d, m, y] = dmy;
    const year = y.length === 2 ? "20" + y : y;
    return `${year}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
  }
  const iso = raw.match(/(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return iso[0];
  return todayISO();
}

function parseTabby(text: string): ParsedSMS | null {
  if (!/tabby/i.test(text)) return null;
  const amount = extractAmount(text);
  if (!amount) return null;

  const instMatch = text.match(/(\d+)\s*[\/of]+\s*(\d+)/i);
  const installmentNumber = instMatch ? parseInt(instMatch[1]) : undefined;
  const totalInstallments = instMatch ? parseInt(instMatch[2]) : undefined;

  const dateM = text.match(/due\s+(?:on\s+)?(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})/i);
  const dueDate = dateM ? parseDateStr(dateM[1]) : undefined;

  const merM = text.match(
    /(?:for|at|from)\s+([A-Za-z][A-Za-z0-9\s&'.\-]{1,30}?)(?:[.,]|\s+(?:is|on|due|payment)|$)/i
  );
  const merchant = merM ? merM[1].trim() : "Tabby";

  return {
    amount,
    merchant,
    date: todayISO(),
    type: "installment",
    provider: "Tabby",
    installmentNumber,
    totalInstallments,
    dueDate,
  };
}

function parseTamara(text: string): ParsedSMS | null {
  if (!/tamara/i.test(text)) return null;
  const amount = extractAmount(text);
  if (!amount) return null;

  const instMatch = text.match(/(\d+)\s*[\/of]+\s*(\d+)/i);
  const installmentNumber = instMatch ? parseInt(instMatch[1]) : undefined;
  const totalInstallments = instMatch ? parseInt(instMatch[2]) : undefined;

  const dateM = text.match(/due\s+(?:on\s+)?(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})/i);
  const dueDate = dateM ? parseDateStr(dateM[1]) : undefined;

  const merM = text.match(
    /(?:at|for|order at)\s+([A-Za-z][A-Za-z0-9\s&'.\-]{1,30}?)(?:[.,]|\s+is|$)/i
  );
  const merchant = merM ? merM[1].trim() : "Tamara";

  return {
    amount,
    merchant,
    date: todayISO(),
    type: "installment",
    provider: "Tamara",
    installmentNumber,
    totalInstallments,
    dueDate,
  };
}

function parseAlRajhi(text: string): ParsedSMS | null {
  if (!/alrajhi|الراجحي|al rajhi/i.test(text)) return null;
  const amount = extractAmount(text);
  if (!amount) return null;

  const isCredit = /credit|إيداع|credited/i.test(text);

  const merM = text.match(
    /(?:at|لدى)\s+([A-Za-zأ-ي][A-Za-zأ-ي0-9\s&'.\-]{1,30}?)(?:\s+on\s+|\s+في|\s*[,.]|$)/i
  );
  const merchant = merM ? merM[1].trim() : "AlRajhi";

  const dateM = text.match(/(?:on|في)\s+(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})/i);
  const date = dateM ? parseDateStr(dateM[1]) : todayISO();

  return {
    amount,
    merchant,
    date,
    type: isCredit ? "credit" : "debit",
    provider: "AlRajhi",
  };
}

function parseSAB(text: string): ParsedSMS | null {
  if (!/\bsab\b/i.test(text)) return null;
  const amount = extractAmount(text);
  if (!amount) return null;

  const isCredit = /credit|credited/i.test(text);
  const merM = text.match(
    /(?:at|from)\s+([A-Za-z][A-Za-z0-9\s&'.\-]{1,30}?)(?:[.,]|\s+(?:available|card|on|for)|$)/i
  );
  const merchant = merM ? merM[1].trim() : "SAB";

  return {
    amount,
    merchant,
    date: todayISO(),
    type: isCredit ? "credit" : "debit",
    provider: "SAB",
  };
}

function parseSTCPay(text: string): ParsedSMS | null {
  if (!/stc\s*pay/i.test(text)) return null;
  const amount = extractAmount(text);
  if (!amount) return null;

  const isCredit = /credit|إيداع|received/i.test(text);
  const merM = text.match(
    /(?:at|لدى|from)\s+([A-Za-zأ-ي][A-Za-zأ-ي0-9\s&'.\-]{1,30}?)(?:[.,]|$)/i
  );
  const merchant = merM ? merM[1].trim() : "STC Pay";

  return {
    amount,
    merchant,
    date: todayISO(),
    type: isCredit ? "credit" : "debit",
    provider: "STC Pay",
  };
}

function parseGeneric(text: string): ParsedSMS | null {
  const amount = extractAmount(text);
  if (!amount) return null;

  const merM = text.match(
    /(?:at|from|لدى)\s+([A-Za-zأ-ي][A-Za-zأ-ي0-9\s&'.\-]{2,30})/i
  );
  const merchant = merM ? merM[1].trim() : "Unknown";

  return {
    amount,
    merchant,
    date: todayISO(),
    type: "debit",
    provider: "Unknown",
  };
}
