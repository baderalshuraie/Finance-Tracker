// Web fallback — uses AsyncStorage. Metro auto-selects db.native.ts on iOS/Android.
import AsyncStorage from "@react-native-async-storage/async-storage";

const KEYS = {
  transactions: "mizan:transactions",
  budgets: "mizan:budgets",
  merchantMap: "mizan:merchantMap",
} as const;

async function readJSON<T>(key: string, fallback: T): Promise<T> {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

async function writeJSON(key: string, value: unknown): Promise<void> {
  await AsyncStorage.setItem(key, JSON.stringify(value));
}

export async function initDatabase(): Promise<void> {
  // AsyncStorage needs no schema init
}

export interface Transaction {
  id: string;
  amount: number;
  merchant: string;
  category: string;
  date: string;
  type: "debit" | "credit" | "installment";
  provider?: string;
  notes?: string;
  installmentNumber?: number;
  totalInstallments?: number;
  dueDate?: string;
  createdAt: string;
}

export async function insertTransaction(t: Transaction): Promise<void> {
  const list = await readJSON<Transaction[]>(KEYS.transactions, []);
  list.unshift(t);
  await writeJSON(KEYS.transactions, list);
}

export async function getTransactions(since?: string): Promise<Transaction[]> {
  const list = await readJSON<Transaction[]>(KEYS.transactions, []);
  if (since) return list.filter((t) => t.date >= since);
  return list;
}

export async function deleteTransaction(id: string): Promise<void> {
  const list = await readJSON<Transaction[]>(KEYS.transactions, []);
  await writeJSON(KEYS.transactions, list.filter((t) => t.id !== id));
}

export async function updateTransactionCategory(id: string, category: string): Promise<void> {
  const list = await readJSON<Transaction[]>(KEYS.transactions, []);
  await writeJSON(KEYS.transactions, list.map((t) => (t.id === id ? { ...t, category } : t)));
}

export interface BudgetLimit {
  category: string;
  monthlyLimit: number;
}

export async function getBudgetLimits(): Promise<BudgetLimit[]> {
  return readJSON<BudgetLimit[]>(KEYS.budgets, []);
}

export async function setBudgetLimit(category: string, monthlyLimit: number): Promise<void> {
  const list = await readJSON<BudgetLimit[]>(KEYS.budgets, []);
  const exists = list.find((b) => b.category === category);
  if (exists) {
    await writeJSON(KEYS.budgets, list.map((b) => (b.category === category ? { ...b, monthlyLimit } : b)));
  } else {
    await writeJSON(KEYS.budgets, [...list, { category, monthlyLimit }]);
  }
}

export async function deleteBudgetLimit(category: string): Promise<void> {
  const list = await readJSON<BudgetLimit[]>(KEYS.budgets, []);
  await writeJSON(KEYS.budgets, list.filter((b) => b.category !== category));
}

export async function getMerchantCategory(merchant: string): Promise<string | null> {
  const map = await readJSON<Record<string, string>>(KEYS.merchantMap, {});
  return map[merchant.toLowerCase()] ?? null;
}

export async function setMerchantCategory(merchant: string, category: string): Promise<void> {
  const map = await readJSON<Record<string, string>>(KEYS.merchantMap, {});
  map[merchant.toLowerCase()] = category;
  await writeJSON(KEYS.merchantMap, map);
}

export async function clearAllData(): Promise<void> {
  await AsyncStorage.multiRemove(Object.values(KEYS));
}
