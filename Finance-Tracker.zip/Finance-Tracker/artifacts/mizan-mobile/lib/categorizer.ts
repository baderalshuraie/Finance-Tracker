import { getMerchantCategory } from "./db";

const RULES: { pattern: RegExp; category: string }[] = [
  // BNPL (checked first for provider names)
  { pattern: /\b(tabby|tamara)\b/i, category: "bnpl_installment" },

  // Food & Dining
  {
    pattern:
      /\b(hungerstation|جاهزة|mrsool|مرسول|talabat|طلبات|shawarmer|albaik|البيك|mcdonalds|kfc|burger king|pizza hut|dominos|starbucks|dunkin|costa|krispy kreme|chilis|applebees|ihop|tgifridays|subway|hardees|popeyes|baskin|coldstone|orange julius|jahmeel|نانسيز|sushi|sashimi|wagamama|cheesecake factory|kudu)\b/i,
    category: "food",
  },

  // Groceries
  {
    pattern:
      /\b(tamimi|تميمي|danube|الدانوب|carrefour|كارفور|panda|بنده|lulu|لولو|othaim|العثيم|hyperone|هايبر|al raya|الراية|farm|فارم|astra|أسترا|geant|جيان)\b/i,
    category: "groceries",
  },

  // Transport
  {
    pattern:
      /\b(uber|careem|كريم|saptco|saudi bus|taxi|fuel|petrol|shell|aramco|total|نيوم|أوبر)\b/i,
    category: "transport",
  },

  // Shopping
  {
    pattern:
      /\b(noon|نون|amazon|أمازون|shein|namshi|نمشي|aldo|h&m|zara|زارا|extra|إكسترا|jarir|جرير|virgin|ايتوز|bayara|mothercare|baby shop|bath body|mac cosmetics|sephora|nyx|la mer|clinique|ikea|home centre|pan emirates|pottery barn|toys r us|lego|sun & sand|adidas|nike|puma|new balance|under armour|footlocker|centrepoint|max fashion|next|matalan|gant|tommy|gucci|chanel|dior|louis vuitton|burberry|armani)\b/i,
    category: "shopping",
  },

  // Healthcare
  {
    pattern:
      /\b(sulaiman|سليمان|habib|الحبيب|sehha|صحة|mouwasat|مواساة|nmc|kingdom hospital|dr|clinic|pharmacy|صيدلية|hospital|مستشفى|medical|tibbiyah|specialized)\b/i,
    category: "healthcare",
  },

  // Transfers
  {
    pattern: /\b(transfer|تحويل|payment|send money|wire|remittance|حوالة)\b/i,
    category: "transfers",
  },
];

export async function categorize(
  merchant: string,
  provider?: string
): Promise<string> {
  // 1. Check user's learned merchant→category map
  const learned = await getMerchantCategory(merchant);
  if (learned) return learned;

  // 2. Check BNPL provider
  if (
    provider &&
    (provider.toLowerCase() === "tabby" ||
      provider.toLowerCase() === "tamara")
  ) {
    return "bnpl_installment";
  }

  // 3. Apply keyword rules
  const text = `${merchant} ${provider ?? ""}`;
  for (const rule of RULES) {
    if (rule.pattern.test(text)) return rule.category;
  }

  return "other";
}

export function categorizeSync(merchant: string, provider?: string): string {
  if (
    provider &&
    (provider.toLowerCase() === "tabby" ||
      provider.toLowerCase() === "tamara")
  ) {
    return "bnpl_installment";
  }

  const text = `${merchant} ${provider ?? ""}`;
  for (const rule of RULES) {
    if (rule.pattern.test(text)) return rule.category;
  }

  return "other";
}
