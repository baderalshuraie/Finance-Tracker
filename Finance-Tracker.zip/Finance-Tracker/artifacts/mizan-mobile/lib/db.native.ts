import * as SQLite from "expo-sqlite";

let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;

async function getDb(): Promise<SQLite.SQLiteDatabase> {
  if (!dbPromise) {
    dbPromise = SQLite.openDatabaseAsync("mizan.db");
  }
  return dbPromise;
}

export async function initDatabase(): Promise<void> {
  const db = await getDb();
  await db.execAsync(`
    PRAGMA journal_mode = WAL;

    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      amount REAL NOT NULL,
      merchant TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'other',
      date TEXT NOT NULL,
      type TEXT NOT NULL,
      provider TEXT,
      notes TEXT,
      installment_number INTEGER,
      total_installments INTEGER,
      due_date TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS budget_limits (
      category TEXT PRIMARY KEY,
      monthly_limit REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS merchant_category_map (
      merchant TEXT PRIMARY KEY,
      category TEXT NOT NULL
    );
  `);
}

export interface Transaction {
  id: string;
  amount: number;
  merchant: string;
  category: string;
  date: string;
  type: "debit" | "credit" | "installment";
  provider?: string;
  notes?: string;
  installmentNumber?: number;
  totalInstallments?: number;
  dueDate?: string;
  createdAt: string;
}

export async function insertTransaction(t: Transaction): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO transactions
       (id, amount, merchant, category, date, type, provider, notes,
        installment_number, total_installments, due_date, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    t.id, t.amount, t.merchant, t.category, t.date, t.type,
    t.provider ?? null, t.notes ?? null,
    t.installmentNumber ?? null, t.totalInstallments ?? null,
    t.dueDate ?? null, t.createdAt
  );
}

export async function getTransactions(since?: string): Promise<Transaction[]> {
  const db = await getDb();
  const rows: any[] = since
    ? await db.getAllAsync(
        `SELECT * FROM transactions WHERE date >= ? ORDER BY date DESC`, since
      )
    : await db.getAllAsync(
        `SELECT * FROM transactions ORDER BY date DESC`
      );
  return rows.map(rowToTransaction);
}

export async function deleteTransaction(id: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`DELETE FROM transactions WHERE id = ?`, id);
}

export async function updateTransactionCategory(id: string, category: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE transactions SET category = ? WHERE id = ?`, category, id);
}

function rowToTransaction(row: any): Transaction {
  return {
    id: row.id, amount: row.amount, merchant: row.merchant,
    category: row.category, date: row.date,
    type: row.type as Transaction["type"],
    provider: row.provider ?? undefined,
    notes: row.notes ?? undefined,
    installmentNumber: row.installment_number ?? undefined,
    totalInstallments: row.total_installments ?? undefined,
    dueDate: row.due_date ?? undefined,
    createdAt: row.created_at,
  };
}

export interface BudgetLimit {
  category: string;
  monthlyLimit: number;
}

export async function getBudgetLimits(): Promise<BudgetLimit[]> {
  const db = await getDb();
  const rows = (await db.getAllAsync(`SELECT * FROM budget_limits`)) as any[];
  return rows.map((r) => ({ category: r.category, monthlyLimit: r.monthly_limit }));
}

export async function setBudgetLimit(category: string, monthlyLimit: number): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO budget_limits (category, monthly_limit) VALUES (?, ?)
     ON CONFLICT(category) DO UPDATE SET monthly_limit = excluded.monthly_limit`,
    category, monthlyLimit
  );
}

export async function deleteBudgetLimit(category: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`DELETE FROM budget_limits WHERE category = ?`, category);
}

export async function getMerchantCategory(merchant: string): Promise<string | null> {
  const db = await getDb();
  const row = (await db.getFirstAsync(
    `SELECT category FROM merchant_category_map WHERE LOWER(merchant) = LOWER(?)`, merchant
  )) as any;
  return row?.category ?? null;
}

export async function setMerchantCategory(merchant: string, category: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO merchant_category_map (merchant, category) VALUES (?, ?)
     ON CONFLICT(merchant) DO UPDATE SET category = excluded.category`,
    merchant, category
  );
}

export async function clearAllData(): Promise<void> {
  const db = await getDb();
  await db.execAsync(`
    DELETE FROM transactions;
    DELETE FROM budget_limits;
    DELETE FROM merchant_category_map;
  `);
}
