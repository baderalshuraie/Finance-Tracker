import { useApp } from "@/context/AppContext";
import { getCategoryById } from "@/constants/categories";

/**
 * Returns the effective display label for a category ID,
 * preferring the user's custom rename over the default.
 */
export function useCategoryLabel(categoryId: string): string {
  const { categoryLabels } = useApp();
  return categoryLabels[categoryId] ?? getCategoryById(categoryId).label;
}
