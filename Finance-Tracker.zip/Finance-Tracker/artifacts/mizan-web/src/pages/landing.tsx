import { motion } from "framer-motion";
import { WaitlistForm } from "@/components/waitlist-form";
import { Wallet, Bell, LineChart, MessageSquare, ChevronDown } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background selection:bg-primary/30 selection:text-primary">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 border-b border-white/5 bg-background/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-primary flex items-center justify-center">
              <div className="w-3 h-3 rounded-full bg-background" />
            </div>
            <span className="text-2xl font-bold font-arabic text-foreground tracking-wide mt-1">ميزان</span>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-40 pb-32 overflow-hidden flex flex-col items-center justify-center min-h-[90vh]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(200,150,80,0.08),transparent_50%)]" />
        <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              <span className="text-sm font-medium tracking-wide">The first GCC-native wealth aggregator</span>
            </div>
            
            <h1 className="text-6xl md:text-8xl font-bold tracking-tight text-foreground mb-6">
              Balance your wealth.<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/60 font-arabic pb-2">
                بكل دقة.
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
              Tabby here, Tamara there, local banks everywhere. 
              See your true financial exposure in one unified, intelligent dashboard.
            </p>

            <div className="max-w-md mx-auto">
              <WaitlistForm />
            </div>
          </motion.div>
        </div>

        <motion.div 
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-muted-foreground animate-bounce"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
        >
          <ChevronDown className="w-6 h-6" />
        </motion.div>
      </section>

      {/* The Problem Section */}
      <section className="py-32 bg-secondary/30 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-4xl font-bold mb-6">You're richer than you think. Or poorer. <br /><span className="text-primary">You just don't know.</span></h2>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                The modern Saudi professional's dilemma: Salary hits the bank, but parts of it are already spoken for. When BNPL commitments are scattered across multiple apps, tracking your true net worth becomes a guessing game.
              </p>
              <ul className="space-y-4">
                {[
                  "No more mental math at the end of the month.",
                  "Instantly view upcoming BNPL installments.",
                  "Align your spending with the local salary cycle."
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle className="w-6 h-6 text-primary shrink-0" />
                    <span className="text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative aspect-square md:aspect-[4/5] rounded-2xl bg-gradient-to-br from-secondary to-background border border-white/10 p-8 shadow-2xl flex flex-col justify-between overflow-hidden"
            >
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(200,150,80,0.15),transparent_70%)]" />
              <div className="space-y-6 relative z-10">
                <div className="flex justify-between items-end border-b border-white/10 pb-6">
                  <div>
                    <p className="text-sm text-muted-foreground uppercase tracking-wider mb-1">TRUE BALANCE</p>
                    <p className="text-4xl font-bold font-mono">SAR 12,450</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-destructive uppercase tracking-wider mb-1">BNPL EXPOSURE</p>
                    <p className="text-xl font-bold font-mono text-destructive">- SAR 3,200</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  {[
                    { label: "Tabby Installment", date: "24th", amount: "850", color: "bg-blue-500/20 text-blue-400" },
                    { label: "Tamara Split", date: "26th", amount: "1,200", color: "bg-pink-500/20 text-pink-400" },
                    { label: "STC Pay Auto-transfer", date: "28th", amount: "1,150", color: "bg-purple-500/20 text-purple-400" }
                  ].map((tx, i) => (
                    <div key={i} className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5">
                      <div className="flex gap-4 items-center">
                        <div className={`px-2 py-1 rounded text-xs font-bold ${tx.color}`}>{tx.date}</div>
                        <span className="font-medium">{tx.label}</span>
                      </div>
                      <span className="font-mono text-muted-foreground">- {tx.amount}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-32">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-20">
            <h2 className="text-4xl font-bold mb-6">Engineered for precision.</h2>
            <p className="text-lg text-muted-foreground">
              Mizan connects the dots between your bank accounts, digital wallets, and BNPL providers to give you a single source of truth.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: MessageSquare,
                title: "SMS Import",
                description: "Paste any SMS from Alrajhi, SAB, STC Pay, Tabby, or Tamara. Mizan parses the amount, merchant, and date in seconds."
              },
              {
                icon: Wallet,
                title: "Unified BNPL Tracking",
                description: "Tabby, Tamara, and local installments aggregated into a single timeline mapped to your salary date."
              },
              {
                icon: LineChart,
                title: "Auto-Categorization",
                description: "Smart rules that understand Saudi merchants. From Al Baik to Jarir, your spending is sorted instantly."
              },
              {
                icon: Bell,
                title: "Budget Alerts",
                description: "Set a monthly limit per category. Get a warning at 80% and 100% so you never overspend."
              }
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2, duration: 0.6 }}
                className="p-8 rounded-2xl bg-secondary/50 border border-white/5 hover:border-primary/50 transition-colors"
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Teaser Section */}
      <section className="py-32 bg-background border-t border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(200,150,80,0.05),transparent_50%)]" />
        <div className="max-w-5xl mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">Clear boundaries. Zero surprises.</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="p-10 rounded-2xl border border-white/10 bg-secondary/30">
              <h3 className="text-2xl font-bold mb-2">Mizan Base</h3>
              <p className="text-muted-foreground mb-8">For the organized professional.</p>
              <div className="text-4xl font-bold mb-8">Free</div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3"><CheckCircle className="w-5 h-5 text-muted-foreground" /> <span>Basic aggregation</span></li>
                <li className="flex items-center gap-3"><CheckCircle className="w-5 h-5 text-muted-foreground" /> <span>1 Bank connection</span></li>
                <li className="flex items-center gap-3"><CheckCircle className="w-5 h-5 text-muted-foreground" /> <span>Monthly summaries</span></li>
              </ul>
            </div>

            <div className="p-10 rounded-2xl border border-primary bg-primary/5 relative">
              <div className="absolute top-0 right-8 -translate-y-1/2 px-3 py-1 bg-primary text-primary-foreground text-xs font-bold uppercase tracking-wider rounded-full">
                Waitlist Only
              </div>
              <h3 className="text-2xl font-bold mb-2 text-primary">Mizan Pro</h3>
              <p className="text-muted-foreground mb-8">For the financially obsessed.</p>
              <div className="text-4xl font-bold mb-8">SAR 29<span className="text-xl text-muted-foreground font-normal">/mo</span></div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3"><CheckCircle className="w-5 h-5 text-primary" /> <span className="font-medium text-foreground">Unlimited connections</span></li>
                <li className="flex items-center gap-3"><CheckCircle className="w-5 h-5 text-primary" /> <span className="font-medium text-foreground">Live BNPL sync</span></li>
                <li className="flex items-center gap-3"><CheckCircle className="w-5 h-5 text-primary" /> <span className="font-medium text-foreground">Custom salary cycles</span></li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <footer className="py-24 bg-secondary/80 border-t border-white/10 text-center">
        <div className="max-w-2xl mx-auto px-6">
          <h2 className="text-3xl font-bold mb-8">Ready to see your true balance?</h2>
          <WaitlistForm />
          <p className="mt-12 text-sm text-muted-foreground">
            © {new Date().getFullYear()} Mizan Finance. Built for the GCC.
          </p>
        </div>
      </footer>
    </div>
  );
}

function CheckCircle(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  );
}
