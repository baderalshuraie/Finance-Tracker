import { useListWaitlist } from "@workspace/api-client-react";
import { format } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function AdminWaitlist() {
  const { data: signups, isLoading, isError } = useListWaitlist();

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground font-arabic">ميزان Admin</h1>
          <p className="text-muted-foreground mt-2">Manage waitlist signups and incoming interest.</p>
        </div>

        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle>Waitlist Signups</CardTitle>
            <CardDescription>
              A complete list of users who have requested early access.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Skeleton key={i} className="h-12 w-full bg-secondary/50" />
                ))}
              </div>
            ) : isError ? (
              <div className="p-4 bg-destructive/10 text-destructive rounded-md border border-destructive/20">
                Failed to load waitlist data. Please try again later.
              </div>
            ) : !signups || signups.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground border border-dashed border-border rounded-lg">
                No signups yet.
              </div>
            ) : (
              <div className="rounded-md border border-border overflow-hidden">
                <Table>
                  <TableHeader className="bg-secondary/50">
                    <TableRow className="border-border hover:bg-transparent">
                      <TableHead className="font-medium text-muted-foreground">Email</TableHead>
                      <TableHead className="font-medium text-muted-foreground">Phone</TableHead>
                      <TableHead className="font-medium text-muted-foreground">Source</TableHead>
                      <TableHead className="font-medium text-muted-foreground text-right">Joined Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {signups.map((signup) => (
                      <TableRow key={signup.id} className="border-border hover:bg-secondary/30">
                        <TableCell className="font-medium">{signup.email}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {signup.phone || "—"}
                        </TableCell>
                        <TableCell>
                          <span className="inline-flex items-center rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
                            {signup.source || "unknown"}
                          </span>
                        </TableCell>
                        <TableCell className="text-right text-muted-foreground">
                          {format(new Date(signup.createdAt), "MMM d, yyyy")}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
