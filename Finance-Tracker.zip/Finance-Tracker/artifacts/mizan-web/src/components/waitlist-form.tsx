import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useJoinWaitlist } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { CheckCircle2, ArrowRight } from "lucide-react";

const formSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().optional(),
});

export function WaitlistForm() {
  const [isSuccess, setIsSuccess] = useState(false);
  const joinWaitlist = useJoinWaitlist();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      phone: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    joinWaitlist.mutate(
      {
        data: {
          email: values.email,
          phone: values.phone || null,
          source: "landing",
        },
      },
      {
        onSuccess: () => {
          setIsSuccess(true);
        },
      }
    );
  }

  if (isSuccess) {
    return (
      <div className="flex flex-col items-center justify-center space-y-4 p-8 bg-secondary/50 rounded-xl border border-border" data-testid="success-message">
        <CheckCircle2 className="w-12 h-12 text-primary" />
        <div className="text-center space-y-2">
          <h3 className="text-xl font-medium text-foreground font-arabic">تم التسجيل بنجاح</h3>
          <p className="text-muted-foreground">You're on the list. We'll be in touch soon.</p>
        </div>
      </div>
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4" data-testid="form-waitlist">
        <div className="flex flex-col sm:flex-row gap-3">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem className="flex-1">
                <FormControl>
                  <Input 
                    placeholder="Enter your email" 
                    className="h-12 bg-background border-border focus-visible:ring-primary" 
                    data-testid="input-email"
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button 
            type="submit" 
            className="h-12 px-8 font-medium group transition-all" 
            disabled={joinWaitlist.isPending}
            data-testid="button-submit"
          >
            {joinWaitlist.isPending ? (
              "Joining..."
            ) : (
              <>
                Join Waitlist
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </>
            )}
          </Button>
        </div>
        <FormField
          control={form.control}
          name="phone"
          render={({ field }) => (
            <FormItem>
              <FormControl>
                <Input 
                  placeholder="Phone number (optional)" 
                  className="h-12 bg-background border-border focus-visible:ring-primary" 
                  data-testid="input-phone"
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </form>
    </Form>
  );
}
